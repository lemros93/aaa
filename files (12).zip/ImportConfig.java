package sk.moja.db.importer.config;

import static sk.moja.enumerators.Constants.DESTINATION;
import static sk.moja.enumerators.Constants.LOCAL_DESTINATION;

public class ImportConfig {

    // required
    public final String ndjsonPath;
    public final String stepsExtraPath;
    public final String dbUrl;
    public final String dbUser;
    public final String dbPassword;

    // run info
    public final String project;
    public final String environment;
    public final String branch;
    public final String commitHash;
    public final String commitMessage;
    public final String buildNumber;
    public final String triggeredBy;
    public final String triggerType;
    public final String parallelMode;   // serial / parallel
    public final int    threadCount;

    // web specific metadata
    public final String browser;
    public final String browserVersion;
    public final String appUrl;

    private ImportConfig(Builder b) {
        this.ndjsonPath     = b.ndjsonPath;
        this.stepsExtraPath = b.stepsExtraPath;
        this.dbUrl          = b.dbUrl;
        this.dbUser         = b.dbUser;
        this.dbPassword     = b.dbPassword;
        this.project        = b.project;
        this.environment    = b.environment;
        this.branch         = b.branch;
        this.commitHash     = b.commitHash;
        this.commitMessage  = b.commitMessage;
        this.buildNumber    = b.buildNumber;
        this.triggeredBy    = b.triggeredBy;
        this.triggerType    = b.triggerType;
        this.parallelMode   = b.parallelMode;
        this.threadCount    = b.threadCount;
        this.browser        = b.browser;
        this.browserVersion = b.browserVersion;
        this.appUrl         = b.appUrl;
    }

    public static ImportConfig fromSystemProperties() {
        return new Builder()
            .ndjsonPath    (prop("ndjson",          LOCAL_DESTINATION + DESTINATION + "/temp/reports/cucumber-report/cucumber.ndjson"))
            .stepsExtraPath(prop("steps.extra",     LOCAL_DESTINATION + DESTINATION + "/temp/reports/cucumber-report/cucumberextra.ndjson"))
            .dbUrl         (require("db.url"))
            .dbUser        (require("db.user"))
            .dbPassword    (require("db.password"))
            .project       (prop("project",         "web-project"))
            .environment   (prop("env",             "unknown"))
            .branch        (prop("branch",          "unknown"))
            .commitHash    (prop("commit.hash",     "unknown"))
            .commitMessage (prop("commit.message",  ""))
            .buildNumber   (prop("build.number",    "unknown"))
            .triggeredBy   (prop("triggered.by",    "unknown"))
            .triggerType   (prop("trigger.type",    "manual"))
            .parallelMode  (prop("parallel.mode",   "serial"))
            .threadCount   (Integer.parseInt(prop("thread.count", "1")))
            .browser       (prop("browser",         "unknown"))
            .browserVersion(prop("browser.version", "unknown"))
            .appUrl        (prop("app.url",         ""))
            .build();
    }

    private static String require(String key) {
        String val = System.getProperty(key);
        if (val == null || val.isBlank())
            throw new IllegalArgumentException("Required system property missing: -D" + key);
        return val;
    }

    private static String prop(String key, String defaultValue) {
        String val = System.getProperty(key);
        return (val != null && !val.isBlank()) ? val : defaultValue;
    }

    public static class Builder {
        private String ndjsonPath, stepsExtraPath, dbUrl, dbUser, dbPassword;
        private String project, environment, branch, commitHash, commitMessage, buildNumber;
        private String triggeredBy, triggerType, parallelMode;
        private int    threadCount = 1;
        private String browser, browserVersion, appUrl;

        public Builder ndjsonPath    (String v) { this.ndjsonPath     = v; return this; }
        public Builder stepsExtraPath(String v) { this.stepsExtraPath = v; return this; }
        public Builder dbUrl         (String v) { this.dbUrl          = v; return this; }
        public Builder dbUser        (String v) { this.dbUser         = v; return this; }
        public Builder dbPassword    (String v) { this.dbPassword     = v; return this; }
        public Builder project       (String v) { this.project        = v; return this; }
        public Builder environment   (String v) { this.environment    = v; return this; }
        public Builder branch        (String v) { this.branch         = v; return this; }
        public Builder commitHash    (String v) { this.commitHash     = v; return this; }
        public Builder commitMessage (String v) { this.commitMessage  = v; return this; }
        public Builder buildNumber   (String v) { this.buildNumber    = v; return this; }
        public Builder triggeredBy   (String v) { this.triggeredBy    = v; return this; }
        public Builder triggerType   (String v) { this.triggerType    = v; return this; }
        public Builder parallelMode  (String v) { this.parallelMode   = v; return this; }
        public Builder threadCount   (int v)    { this.threadCount    = v; return this; }
        public Builder browser       (String v) { this.browser        = v; return this; }
        public Builder browserVersion(String v) { this.browserVersion = v; return this; }
        public Builder appUrl        (String v) { this.appUrl         = v; return this; }
        public ImportConfig build()             { return new ImportConfig(this); }
    }
}
