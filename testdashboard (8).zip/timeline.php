<?php
require_once 'config/db.php';
$db         = getDb();
$pageTitle  = 'Timeline – Test Dashboard';
$activePage = 'timeline';

$from     = $_GET['from']     ?? date('Y-m-d', strtotime('-14 days'));
$to       = $_GET['to']       ?? date('Y-m-d');
$project  = $_GET['project']  ?? 'all';
$parallel = $_GET['parallel'] ?? 'all';
$jira     = $_GET['jira']     ?? 'all';
$toEnd    = $to . ' 23:59:59';

$filters = ['r.run_at BETWEEN :from AND :to'];
$params  = [':from' => $from, ':to' => $toEnd];
if ($project  !== 'all') { $filters[] = 'r.project = :project';           $params[':project']  = $project; }
if ($parallel !== 'all') { $filters[] = 'r.parallel_mode = :parallel';    $params[':parallel'] = $parallel; }
if ($jira     !== 'all') { $filters[] = 'r.jira_reporting = :jira';       $params[':jira']     = (int)($jira === 'yes'); }
$where = 'WHERE ' . implode(' AND ', $filters);

$sql = "SELECT r.id, r.project, r.run_at, r.build_number, r.branch,
               r.parallel_mode, r.thread_count,
               r.total_scenarios, r.passed_scenarios, r.failed_scenarios,
               ROUND(r.passed_scenarios/NULLIF(r.total_scenarios,0)*100,1) AS success_rate
        FROM runs r $where ORDER BY r.run_at DESC LIMIT 50";

$stmt = $db->prepare($sql);
foreach ($params as $k => $v) $stmt->bindValue($k, $v);
$stmt->execute();
$runs = $stmt->fetchAll();

include 'partials/header.php';
include 'partials/filters.php';
?>

<div class="main">

<!-- Run selector -->
<div class="table-wrap" style="margin-bottom:16px">
    <div class="table-header">
        <span class="table-title">⏱ Timeline — vyber run</span>
        <span class="table-count"><?= count($runs) ?> runov</span>
    </div>
    <?php if (empty($runs)): ?>
        <div class="empty"><div class="empty-icon">📭</div>Žiadne dáta</div>
    <?php else: ?>
    <table>
        <thead>
            <tr>
                <th>Dátum</th>
                <th>Branch</th>
                <th>Build</th>
                <th>Beh</th>
                <th>Scenáre ✓/✗</th>
                <th>Úspešnosť</th>
                <th></th>
            </tr>
        </thead>
        <tbody>
        <?php foreach ($runs as $r):
            $isP = ($r['parallel_mode'] ?? 'serial') === 'parallel';
            $sr  = $r['success_rate'] ?? 0;
        ?>
            <tr id="run-row-<?= $r['id'] ?>">
                <td class="nowrap"><?= date('d.m.Y H:i', strtotime($r['run_at'])) ?></td>
                <td class="mono"><?= htmlspecialchars($r['branch'] ?? '—') ?></td>
                <td class="mono"><?= htmlspecialchars($r['build_number']) ?></td>
                <td>
                    <?php if ($isP): ?>
                        <span style="color:var(--accent)">⚡ ×<?= (int)$r['thread_count'] ?></span>
                    <?php else: ?>
                        <span class="muted">serial</span>
                    <?php endif; ?>
                </td>
                <td>
                    <span style="color:var(--success)">✓<?= $r['passed_scenarios'] ?></span>
                    <span style="color:var(--danger)"> ✗<?= $r['failed_scenarios'] ?></span>
                    / <?= $r['total_scenarios'] ?>
                </td>
                <td><span class="pct <?= $sr>=80?'good':'bad' ?>"><?= $sr ?>%</span></td>
                <td>
                    <button class="apply-btn" style="padding:4px 12px;font-size:12px"
                            onclick="loadTimeline(<?= $r['id'] ?>, '<?= date('d.m.Y H:i', strtotime($r['run_at'])) ?> — <?= htmlspecialchars($r['build_number']) ?>')">
                        Zobraziť
                    </button>
                </td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    <?php endif; ?>
</div>

<!-- Timeline canvas area -->
<div class="table-wrap" id="timeline-wrap" style="display:none">
    <div class="table-header">
        <span class="table-title">📊 Timeline: <span id="timeline-title"></span></span>
        <div class="flex ml-auto" style="gap:10px;font-size:12px">
            <span style="display:flex;align-items:center;gap:5px">
                <span style="width:12px;height:12px;background:var(--success);border-radius:2px;display:inline-block"></span> passed
            </span>
            <span style="display:flex;align-items:center;gap:5px">
                <span style="width:12px;height:12px;background:var(--danger);border-radius:2px;display:inline-block"></span> failed
            </span>
            <span style="display:flex;align-items:center;gap:5px">
                <span style="width:12px;height:12px;background:var(--skip);border-radius:2px;display:inline-block"></span> skipped
            </span>
        </div>
    </div>

    <div id="timeline-loading" class="empty" style="display:none">
        <div class="spinner" style="margin:0 auto 8px;display:block;width:24px;height:24px"></div>
        Načítavam timeline...
    </div>

    <div id="timeline-container" style="padding:16px;overflow-x:auto"></div>
</div>

</div><!-- .main -->

<!-- Scenario tooltip -->
<div id="tl-tooltip" style="
    display:none; position:fixed; z-index:200;
    background:var(--bg2); border:1px solid var(--border);
    border-radius:6px; padding:10px 14px; font-size:12px;
    box-shadow:var(--shadow); max-width:320px; pointer-events:none">
</div>

<script>
const THREAD_H   = 36;   // height of each thread lane
const THREAD_GAP = 8;    // gap between lanes
const LABEL_W    = 130;  // left label column width
const AXIS_H     = 28;   // time axis height at top
const BAR_H      = 22;   // scenario bar height
const BAR_RADIUS = 3;
const FEAT_COLORS = [    // rotating palette for feature groups
    '#3b5bdb','#0ca678','#e67700','#c92a2a',
    '#5c7cfa','#20c997','#fd7e14','#f03e3e',
    '#748ffc','#63e6be','#ffa94d','#ff8787',
];

let currentTooltipEl = null;

async function loadTimeline(runId, label) {
    document.getElementById('timeline-wrap').style.display = 'block';
    document.getElementById('timeline-title').textContent = label;
    document.getElementById('timeline-loading').style.display = 'block';
    document.getElementById('timeline-container').innerHTML = '';

    // Highlight selected row
    document.querySelectorAll('[id^="run-row-"]').forEach(r => r.style.background = '');
    const row = document.getElementById('run-row-' + runId);
    if (row) row.style.background = 'var(--accent-dim)';

    const data = await fetchJson(`api/dev_data.php?action=timeline&run_id=${runId}`);
    document.getElementById('timeline-loading').style.display = 'none';

    if (!data.threads || Object.keys(data.threads).length === 0) {
        document.getElementById('timeline-container').innerHTML =
            '<div class="empty">Žiadne timeline dáta — scenáre nemajú timestamp.<br><span class="muted">Potrebné: NdjsonParser zachytáva testCaseStarted.timestamp</span></div>';
        return;
    }

    renderTimeline(data.threads);
    document.getElementById('timeline-wrap').scrollIntoView({behavior:'smooth', block:'start'});
}

function renderTimeline(threads) {
    const container = document.getElementById('timeline-container');
    const threadKeys = Object.keys(threads).sort();

    // Compute total duration
    let maxEnd = 0;
    const featureColors = {};
    let colorIdx = 0;
    threadKeys.forEach(t => {
        threads[t].forEach(s => {
            const end = (s.offset_ms || 0) + (s.duration_ms || 0);
            if (end > maxEnd) maxEnd = end;
            if (!featureColors[s.feature_name]) {
                featureColors[s.feature_name] = FEAT_COLORS[colorIdx % FEAT_COLORS.length];
                colorIdx++;
            }
        });
    });

    if (maxEnd === 0) {
        container.innerHTML = '<div class="empty">Žiadne dáta na zobrazenie</div>';
        return;
    }

    // Canvas dimensions
    const W = Math.max(container.clientWidth - LABEL_W - 32, 600);
    const totalH = AXIS_H + threadKeys.length * (THREAD_H + THREAD_GAP);
    const pxPerMs = W / maxEnd;

    // SVG
    let svg = `<svg width="${LABEL_W + W + 20}" height="${totalH + 20}"
                    xmlns="http://www.w3.org/2000/svg"
                    style="font-family:Inter,system-ui,sans-serif">`;

    // Defs — clip path
    svg += `<defs>
        <clipPath id="bars-clip">
            <rect x="${LABEL_W}" y="0" width="${W}" height="${totalH}"/>
        </clipPath>
    </defs>`;

    // Time axis — ticks
    const tickCount = 8;
    const tickMs    = maxEnd / tickCount;
    svg += `<g transform="translate(${LABEL_W},0)">`;
    for (let i = 0; i <= tickCount; i++) {
        const x = Math.round(i * tickMs * pxPerMs);
        const label = formatDuration(Math.round(i * tickMs));
        svg += `<line x1="${x}" y1="${AXIS_H - 6}" x2="${x}" y2="${totalH}"
                       stroke="var(--border)" stroke-width="1"/>`;
        svg += `<text x="${x}" y="${AXIS_H - 10}" text-anchor="middle"
                       font-size="10" fill="var(--text-muted)">${label}</text>`;
    }
    svg += `</g>`;

    // Feature legend (below axis, top of chart)
    let legendX = LABEL_W;
    let legendItems = '';
    Object.entries(featureColors).forEach(([name, color]) => {
        const short = name.length > 25 ? name.substring(0, 24) + '…' : name;
        legendItems += `<g transform="translate(${legendX}, 6)">
            <rect width="10" height="10" fill="${color}" rx="2"/>
            <text x="14" y="9" font-size="10" fill="var(--text)">${escHtml(short)}</text>
        </g>`;
        legendX += Math.min(name.length * 7 + 24, 200);
        if (legendX > LABEL_W + W) legendX = LABEL_W; // wrap (simplified)
    });

    // Thread lanes + bars
    threadKeys.forEach((threadKey, ti) => {
        const y0 = AXIS_H + ti * (THREAD_H + THREAD_GAP);
        const midY = y0 + THREAD_H / 2;

        // Lane background
        const laneBg = ti % 2 === 0 ? 'var(--bg2)' : 'var(--bg3)';
        svg += `<rect x="0" y="${y0}" width="${LABEL_W + W + 20}" height="${THREAD_H}"
                       fill="${laneBg}" rx="0"/>`;

        // Thread label
        const tLabel = threadKey.replace('thread-', 'T').replace('cucumber-runner-', 'T');
        svg += `<text x="${LABEL_W - 8}" y="${midY + 4}" text-anchor="end"
                       font-size="11" font-weight="600" fill="var(--text)">${escHtml(tLabel)}</text>`;

        // Feature separator lines — draw vertical lines where feature changes
        let lastFeature = null;
        threads[threadKey].forEach(s => {
            if (lastFeature && lastFeature !== s.feature_name) {
                const x = LABEL_W + Math.round(s.offset_ms * pxPerMs);
                svg += `<line x1="${x}" y1="${y0}" x2="${x}" y2="${y0 + THREAD_H}"
                               stroke="rgba(255,255,255,0.3)" stroke-width="2" stroke-dasharray="3,2"/>`;
            }
            lastFeature = s.feature_name;
        });

        // Scenario bars
        threads[threadKey].forEach((s, si) => {
            const x   = LABEL_W + Math.round((s.offset_ms || 0) * pxPerMs);
            const w   = Math.max(Math.round((s.duration_ms || 0) * pxPerMs), 3);
            const barY = y0 + (THREAD_H - BAR_H) / 2;

            const featColor = featureColors[s.feature_name];
            let barFill;
            if (s.status === 'passed')  barFill = 'var(--success)';
            else if (s.status === 'failed') barFill = 'var(--danger)';
            else barFill = 'var(--skip)';

            // Feature color stripe at top of bar
            svg += `<rect x="${x}" y="${barY}" width="${w}" height="${BAR_H}"
                           fill="${barFill}" rx="${BAR_RADIUS}"
                           opacity="0.85"
                           style="cursor:pointer"
                           data-sid="${s.id}"
                           onmouseenter="showTooltip(event, ${JSON.stringify(JSON.stringify(s)).slice(1,-1)})"
                           onmouseleave="hideTooltip()"/>`;

            // Feature color stripe (top 3px)
            svg += `<rect x="${x}" y="${barY}" width="${w}" height="3"
                           fill="${featColor}" rx="${BAR_RADIUS}" opacity="0.9"/>`;

            // Label inside bar if wide enough
            if (w > 60) {
                const maxChars = Math.floor((w - 8) / 6);
                const label = s.scenario_name.length > maxChars
                    ? s.scenario_name.substring(0, maxChars - 1) + '…'
                    : s.scenario_name;
                svg += `<text x="${x + 4}" y="${barY + 14}" font-size="10"
                               fill="white" style="pointer-events:none">${escHtml(label)}</text>`;
            }
        });
    });

    svg += '</svg>';
    container.innerHTML = svg;
}

function showTooltip(event, jsonStr) {
    const s = JSON.parse(jsonStr);
    const tip = document.getElementById('tl-tooltip');
    const statusColor = s.status === 'passed' ? 'var(--success)' : s.status === 'failed' ? 'var(--danger)' : 'var(--skip)';

    tip.innerHTML = `
        <div style="font-weight:600;margin-bottom:4px;color:${statusColor}">${escHtml(s.scenario_name)}</div>
        <div style="color:var(--text-muted);font-size:11px;margin-bottom:6px">${escHtml(s.feature_name)}</div>
        <div style="display:grid;grid-template-columns:auto auto;gap:2px 12px;font-size:11px">
            <span class="muted">Status</span><span style="color:${statusColor}">${s.status}</span>
            <span class="muted">Trvanie</span><span>${formatDuration(s.duration_ms)}</span>
            <span class="muted">Vlákno</span><span class="mono">${escHtml(s.thread_id || '—')}</span>
            <span class="muted">Offset</span><span>${formatDuration(s.offset_ms)}</span>
            ${s.tags ? `<span class="muted">Tagy</span><span>${escHtml(s.tags)}</span>` : ''}
        </div>`;

    tip.style.display = 'block';
    positionTooltip(event, tip);
}

function positionTooltip(event, tip) {
    const margin = 12;
    let x = event.clientX + margin;
    let y = event.clientY + margin;
    if (x + 340 > window.innerWidth)  x = event.clientX - 340 - margin;
    if (y + 160 > window.innerHeight) y = event.clientY - 160 - margin;
    tip.style.left = x + 'px';
    tip.style.top  = y + 'px';
}

document.addEventListener('mousemove', e => {
    const tip = document.getElementById('tl-tooltip');
    if (tip.style.display !== 'none') positionTooltip(e, tip);
});

function hideTooltip() {
    document.getElementById('tl-tooltip').style.display = 'none';
}

function escHtml(str) {
    if (!str) return '';
    return String(str).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}
</script>
</body>
</html>
