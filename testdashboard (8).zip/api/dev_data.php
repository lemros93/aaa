<?php
// Suppress HTML errors — return JSON error instead
ini_set('display_errors', 0);
error_reporting(E_ALL);
set_exception_handler(function($e) {
    header('Content-Type: application/json');
    echo json_encode(['error' => $e->getMessage()]);
    exit;
});
set_error_handler(function($errno, $errstr) {
    header('Content-Type: application/json');
    echo json_encode(['error' => $errstr]);
    exit;
});

header('Content-Type: application/json');
require_once '../config/db.php';

$db      = getDb();
$action  = $_GET['action']  ?? 'runs';
$from    = $_GET['from']    ?? date('Y-m-d', strtotime('-14 days'));
$to      = $_GET['to']      ?? date('Y-m-d');
$project = $_GET['project'] ?? 'all';
$toEnd   = $to . ' 23:59:59';

$pf       = $project  !== 'all' ? 'AND r.project = :project'           : '';
$parallel = $_GET['parallel'] ?? 'all';
$paraf    = $parallel !== 'all' ? 'AND r.parallel_mode = :parallel_mode' : '';
$jira     = $_GET['jira']     ?? 'all';
$jiraf    = $jira     !== 'all' ? 'AND r.jira_reporting = :jira_reporting' : '';

switch ($action) {

    // --- Runs list ---
    case 'runs':
        $branch = $_GET['branch'] ?? '';
        $bf     = $branch !== '' ? 'AND r.branch = :branch' : '';
        $sql = "SELECT r.id, r.project, r.run_at, r.build_number, r.branch,
                       r.commit_hash, r.app_url,
                       r.environment, r.triggered_by, r.trigger_type,
                       r.parallel_mode, r.thread_count,
                       r.jira_reporting, r.jira_new_execution, r.jira_cycle_ids,
                       r.cucumber_tags, r.tested_feature, r.test_properties,
                       r.tests_total_ms, r.build_duration_ms,
                       r.total_scenarios, r.passed_scenarios, r.failed_scenarios,
                       ROUND(r.passed_scenarios/NULLIF(r.total_scenarios,0)*100,1) AS success_rate
                FROM runs r
                WHERE r.run_at BETWEEN :from AND :to $pf $paraf $jiraf $bf
                ORDER BY r.run_at DESC";
        $stmt = $db->prepare($sql);
        $stmt->bindValue(':from', $from);
        $stmt->bindValue(':to',   $toEnd);
        if ($project  !== 'all') $stmt->bindValue(':project',        $project);
        if ($parallel !== 'all') $stmt->bindValue(':parallel_mode',  $parallel);
        if ($jira     !== 'all') $stmt->bindValue(':jira_reporting', (int)($jira === 'yes'), PDO::PARAM_INT);
        if ($branch   !== '')    $stmt->bindValue(':branch',         $branch);
        if ($branch   !== '')    $stmt->bindValue(':branch',        $branch);
        $stmt->execute();
        echo json_encode($stmt->fetchAll());
        break;

    // --- Features for a run ---
    case 'features':
        $runId = (int)($_GET['run_id'] ?? 0);
        $stmt = $db->prepare("SELECT id, name, file_path, status, duration_ms, tags,
                                      total_scenarios, passed_scenarios, failed_scenarios
                               FROM features WHERE run_id = ? ORDER BY name");
        $stmt->execute([$runId]);
        echo json_encode($stmt->fetchAll());
        break;

    // --- Scenarios for a feature ---
    case 'scenarios':
        $featureId = (int)($_GET['feature_id'] ?? 0);
        $stmt = $db->prepare("SELECT id, name, status, line, duration_ms, tags,
                                      total_steps, passed_steps, failed_steps, skipped_steps,
                                      hook_error_type, hook_error_message
                               FROM scenarios WHERE feature_id = ? ORDER BY line");
        $stmt->execute([$featureId]);
        echo json_encode($stmt->fetchAll());
        break;

    // --- Steps for a scenario ---
    case 'steps':
        $scenarioId = (int)($_GET['scenario_id'] ?? 0);
        $stmt = $db->prepare("SELECT id, keyword, name, translated_text, line, status,
                                      duration_ms, error_message, stack_trace,
                                      screenshot_url, failed_screenshot_url
                               FROM steps WHERE scenario_id = ? ORDER BY line");
        $stmt->execute([$scenarioId]);
        echo json_encode($stmt->fetchAll());
        break;

    // --- Timeline data for a run ---
    case 'timeline':
        $runId = (int)($_GET['run_id'] ?? 0);
        // Return all scenarios with their feature info, start time and thread
        $stmt = $db->prepare("
            SELECT
                s.id,
                s.name          AS scenario_name,
                s.status,
                s.started_at,
                s.duration_ms,
                s.thread_id,
                s.tags,
                f.id            AS feature_id,
                f.name          AS feature_name,
                f.status        AS feature_status
            FROM scenarios s
            JOIN features f ON f.id = s.feature_id
            WHERE f.run_id = ?
              AND s.started_at > 0
            ORDER BY s.thread_id, s.started_at ASC
        ");
        $stmt->execute([$runId]);
        $rows = $stmt->fetchAll();

        // Group by thread
        $threads = [];
        $minStart = PHP_INT_MAX;
        foreach ($rows as $row) {
            $t = $row['thread_id'] ?? 'thread-1';
            if (!isset($threads[$t])) $threads[$t] = [];
            $threads[$t][] = $row;
            if ($row['started_at'] < $minStart) $minStart = $row['started_at'];
        }

        // Normalize to relative ms from run start
        foreach ($threads as $t => &$scenarios) {
            foreach ($scenarios as &$s) {
                $s['offset_ms'] = $s['started_at'] - $minStart;
            }
        }

        echo json_encode(['threads' => $threads, 'min_start' => $minStart]);
        break;

    default:
        echo json_encode(['error' => 'Unknown action']);
}
