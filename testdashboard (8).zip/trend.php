<?php
require_once 'config/db.php';
$db         = getDb();
$pageTitle  = 'Trend – Test Dashboard';
$activePage = 'trend';

$from     = $_GET['from']     ?? date('Y-m-d', strtotime('-30 days'));
$to       = $_GET['to']       ?? date('Y-m-d');
$project  = $_GET['project']  ?? 'all';
$parallel = $_GET['parallel'] ?? 'all';
$jira     = $_GET['jira']     ?? 'all';
$toEnd    = $to . ' 23:59:59';

$filters = ['run_at BETWEEN :from AND :to'];
$params  = [':from' => $from, ':to' => $toEnd];
if ($project  !== 'all') { $filters[] = 'project = :project';        $params[':project']  = $project; }
if ($parallel !== 'all') { $filters[] = 'parallel_mode = :parallel'; $params[':parallel'] = $parallel; }
if ($jira     !== 'all') { $filters[] = 'jira_reporting = :jira';    $params[':jira']     = (int)($jira === 'yes'); }
$where = 'WHERE ' . implode(' AND ', $filters);

// Daily aggregation
$sql = "SELECT
    DATE(run_at)                                                          AS day,
    COUNT(*)                                                              AS run_count,
    SUM(total_scenarios)                                                  AS total_scenarios,
    SUM(passed_scenarios)                                                 AS passed_scenarios,
    SUM(failed_scenarios)                                                 AS failed_scenarios,
    ROUND(SUM(passed_scenarios)/NULLIF(SUM(total_scenarios),0)*100, 1)   AS success_rate,
    ROUND(AVG(build_duration_ms)/60000, 1)                               AS avg_duration_min
FROM runs $where
GROUP BY DATE(run_at)
ORDER BY day ASC";

$stmt = $db->prepare($sql);
foreach ($params as $k => $v) $stmt->bindValue($k, $v);
$stmt->execute();
$daily = $stmt->fetchAll();

// Per-run data
$sql2 = "SELECT id, run_at, branch, build_number, commit_hash,
    passed_scenarios, failed_scenarios, total_scenarios,
    ROUND(passed_scenarios/NULLIF(total_scenarios,0)*100, 1) AS success_rate,
    ROUND(build_duration_ms/60000, 1)                        AS duration_min
FROM runs $where
ORDER BY run_at ASC";

$stmt2 = $db->prepare($sql2);
foreach ($params as $k => $v) $stmt2->bindValue($k, $v);
$stmt2->execute();
$runs = $stmt2->fetchAll();

include 'partials/header.php';
include 'partials/filters.php';
?>

<div class="main">

<div style="display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-bottom:20px">
    <div class="table-wrap" style="padding:16px">
        <div class="table-header" style="border:none;padding:0 0 12px 0">
            <span class="table-title">📈 Úspešnosť v čase (per run)</span>
        </div>
        <canvas id="chart-success" height="200"></canvas>
    </div>
    <div class="table-wrap" style="padding:16px">
        <div class="table-header" style="border:none;padding:0 0 12px 0">
            <span class="table-title">⏱ Trvanie buildu v čase (min)</span>
        </div>
        <canvas id="chart-duration" height="200"></canvas>
    </div>
</div>

<!-- Daily summary -->
<div class="table-wrap" style="margin-bottom:20px">
    <div class="table-header">
        <span class="table-title">📅 Denný súhrn</span>
        <span class="table-count"><?= count($daily) ?> dní</span>
    </div>
    <table>
        <thead>
            <tr>
                <th>Deň</th><th>Runy</th><th>Scenáre ✓/✗</th>
                <th>Úspešnosť</th><th>Priem. trvanie</th><th>Trend</th>
            </tr>
        </thead>
        <tbody>
        <?php foreach ($daily as $d):
            $rate = $d['success_rate'];
            $color = $rate >= 80 ? 'var(--success)' : ($rate >= 50 ? 'var(--warn)' : 'var(--danger)');
        ?>
            <tr>
                <td class="nowrap"><?= $d['day'] ?></td>
                <td><?= $d['run_count'] ?></td>
                <td>
                    <span style="color:var(--success)">✓<?= $d['passed_scenarios'] ?></span>
                    <span style="color:var(--danger)"> ✗<?= $d['failed_scenarios'] ?></span>
                    / <?= $d['total_scenarios'] ?>
                </td>
                <td><span style="color:<?= $color ?>;font-weight:600"><?= $rate ?>%</span></td>
                <td><?= $d['avg_duration_min'] ?> min</td>
                <td style="min-width:120px">
                    <div class="progress">
                        <div class="progress-pass" style="width:<?= $rate ?>%"></div>
                        <div class="progress-fail" style="width:<?= 100-$rate ?>%"></div>
                    </div>
                </td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
</div>

<!-- Per-run table -->
<div class="table-wrap">
    <div class="table-header">
        <span class="table-title">🏃 Detail runov</span>
        <span class="table-count"><?= count($runs) ?> runov</span>
    </div>
    <table>
        <thead>
            <tr><th>Dátum</th><th>Branch</th><th>Commit</th><th>Build</th><th>Úspešnosť</th><th>Trvanie</th></tr>
        </thead>
        <tbody>
        <?php foreach (array_reverse($runs) as $r):
            $rate   = $r['success_rate'];
            $color  = $rate >= 80 ? 'var(--success)' : ($rate >= 50 ? 'var(--warn)' : 'var(--danger)');
            $commit = $r['commit_hash'] ? substr($r['commit_hash'], 0, 8) : '—';
        ?>
            <tr>
                <td class="nowrap"><?= date('d.m.Y H:i', strtotime($r['run_at'])) ?></td>
                <td class="mono"><?= htmlspecialchars($r['branch'] ?? '—') ?></td>
                <td class="mono"><?= $commit ?></td>
                <td class="mono"><?= htmlspecialchars($r['build_number']) ?></td>
                <td><span style="color:<?= $color ?>;font-weight:600"><?= $rate ?>%</span></td>
                <td class="nowrap"><?= $r['duration_min'] ?> min</td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
</div>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
<script>
const runs   = <?= json_encode(array_values($runs)) ?>;
const labels = runs.map(r => new Date(r.run_at).toLocaleDateString('sk-SK',
    {month:'2-digit', day:'2-digit', hour:'2-digit', minute:'2-digit'}));

const isDark    = document.documentElement.getAttribute('data-theme') !== 'light';
const gridColor = isDark ? 'rgba(255,255,255,0.08)' : 'rgba(0,0,0,0.08)';
const textColor = isDark ? '#7b82a8' : '#6b7499';

const baseOpts = {
    responsive: true,
    plugins: { legend: { display: false } },
    scales: {
        x: { ticks: { color: textColor, maxTicksLimit: 10 }, grid: { color: gridColor } },
        y: { ticks: { color: textColor }, grid: { color: gridColor } }
    }
};

new Chart(document.getElementById('chart-success'), {
    type: 'line',
    data: {
        labels,
        datasets: [{
            data: runs.map(r => r.success_rate),
            borderColor: '#34d399',
            backgroundColor: 'rgba(52,211,153,0.1)',
            fill: true, tension: 0.3, pointRadius: 4,
            pointBackgroundColor: runs.map(r =>
                r.success_rate >= 80 ? '#34d399' : r.success_rate >= 50 ? '#fbbf24' : '#f87171')
        }]
    },
    options: { ...baseOpts, scales: { ...baseOpts.scales,
        y: { ...baseOpts.scales.y, min: 0, max: 100,
             ticks: { color: textColor, callback: v => v + '%' } } } }
});

new Chart(document.getElementById('chart-duration'), {
    type: 'bar',
    data: {
        labels,
        datasets: [{
            data: runs.map(r => r.duration_min),
            backgroundColor: 'rgba(91,138,245,0.7)',
            borderColor: '#5b8af5', borderWidth: 1
        }]
    },
    options: { ...baseOpts, scales: { ...baseOpts.scales,
        y: { ...baseOpts.scales.y, ticks: { color: textColor, callback: v => v + ' min' } } } }
});
</script>
</body>
</html>
