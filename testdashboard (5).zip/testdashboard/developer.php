<?php
require_once 'config/db.php';
require_once 'config/links.php';
$db         = getDb();
$pageTitle  = 'Developer – Test Dashboard';
$activePage = 'developer';

include 'partials/header.php';
include 'partials/filters.php';
?>

<div class="main">

<!-- Scenario search filter -->
<div style="margin-bottom:12px;display:flex;align-items:center;gap:10px;flex-wrap:wrap">
    <span class="filter-label">Filter scenárov</span>
    <input type="text" id="scen-filter" class="filter-input"
           placeholder="🔍 Názov / tag / JIRA-123 / @smoke / regex..."
           style="width:340px" oninput="applyScenFilter()">
    <span class="muted" id="scen-filter-info" style="font-size:12px"></span>
    <button class="quick-btn" onclick="clearScenFilter()">✕ Zrušiť</button>
</div>

<!-- Runs list — each run has its own inline expand -->
<div id="runs-container">
    <div class="table-wrap">
        <div class="table-header">
            <span class="table-title">Runy</span>
            <span class="table-count" id="runs-count"></span>
        </div>
        <div id="runs-body">
            <div class="empty">
                <div class="spinner" style="margin:0 auto 8px;display:block;width:24px;height:24px"></div>
                Načítavam...
            </div>
        </div>
    </div>
</div>

</div>

<script>
const fp = filterParams();
var scenFilterRegex = null;
const BAMBOO_URL       = '<?= BAMBOO_URL ?>';
const JIRA_URL         = '<?= JIRA_URL ?>';
const JIRA_CYCLE_PATH  = '<?= JIRA_CYCLE_PATH ?>';

// ── Load runs ────────────────────────────────────────────────
async function loadRuns() {
    const data = await fetchJson(
        `api/dev_data.php?action=runs&from=${fp.from}&to=${fp.to}&project=${fp.project}&parallel=${fp.parallel||'all'}&jira=${fp.jira||'all'}`
    );
    document.getElementById('runs-count').textContent = data.length + ' runov';
    if (!data.length) {
        document.getElementById('runs-body').innerHTML =
            '<div class="empty"><div class="empty-icon">📭</div>Žiadne dáta</div>';
        return;
    }

    let html = '<table><thead><tr>'
        + '<th></th><th>Dátum</th><th>Branch</th><th>Commit</th><th>Build</th><th>Beh</th>'
        + '<th>Scenáre ✓/✗</th><th>Úspešnosť</th><th>Čas buildu</th>'
        + '</tr></thead><tbody id="runs-tbody">';

    data.forEach(r => {
        const rate   = r.success_rate || 0;
        const commit = r.commit_hash ? r.commit_hash.substring(0,8) : '—';
        const isP    = r.parallel_mode === 'parallel';
        html += `
        <tr data-id="${r.id}">
            <td style="width:32px">
                <button class="expand-btn" id="rbtn-${r.id}" onclick="toggleRun(this,${r.id},${JSON.stringify(r).replace(/"/g,'&quot;')})">+</button>
            </td>
            <td class="nowrap">${formatDate(r.run_at)}</td>
            <td class="mono">${escHtml(r.branch||'—')}</td>
            <td class="mono" title="${escHtml(r.commit_hash||'')}">${escHtml(commit)}</td>
            <td class="mono">${BAMBOO_URL
                ? `<a href="${BAMBOO_URL}/browse/${escHtml(r.build_number)}" target="_blank">${escHtml(r.build_number)}</a>`
                : escHtml(r.build_number)}</td>
            <td>${isP
                ? `<span style="color:var(--accent)">⚡ ×${r.thread_count}</span>`
                : '<span class="muted">serial</span>'}</td>
            <td>
                <span style="color:var(--success)">✓${r.passed_scenarios}</span>
                <span style="color:var(--danger)"> ✗${r.failed_scenarios}</span>
                / ${r.total_scenarios}
            </td>
            <td><span class="pct ${rate>=80?'good':'bad'}">${rate}%</span></td>
            <td class="nowrap">${formatDuration(r.build_duration_ms)}</td>
        </tr>
        <!-- Inline expand row for this run -->
        <tr id="rrow-${r.id}" style="display:none">
            <td colspan="99" style="padding:0;border-top:2px solid var(--accent)">
                <div style="padding:12px 16px 16px 40px;background:var(--bg)">
                    <!-- Run info mini-grid -->
                    <div id="rinfo-${r.id}" style="display:grid;grid-template-columns:repeat(auto-fit,minmax(140px,1fr));gap:8px;padding:10px 0 14px 0;border-bottom:1px solid var(--border);margin-bottom:12px;font-size:12px">
                    </div>
                    <!-- Features -->
                    <div id="rfeat-${r.id}">
                        <div style="padding:12px;text-align:center">
                            <div class="spinner" style="margin:0 auto;width:20px;height:20px"></div>
                        </div>
                    </div>
                </div>
            </td>
        </tr>`;
    });
    html += '</tbody></table>';
    document.getElementById('runs-body').innerHTML = html;
}

// ── Toggle run expand ────────────────────────────────────────
function toggleRun(btn, runId, runData) {
    const row  = document.getElementById('rrow-' + runId);
    const open = row.style.display === 'none';
    row.style.display = open ? 'table-row' : 'none';
    btn.classList.toggle('open', open);
    if (open && !row.dataset.loaded) {
        row.dataset.loaded = '1';
        renderRunInfo(runId, runData);
        loadFeatures(runId);
    }
}

function renderRunInfo(runId, r) {
    const isP    = r.parallel_mode === 'parallel';
    const isJira = r.jira_reporting == 1 || r.jira_reporting === true;
    const items  = [
        ['Spustil',      r.triggered_by || '—'],
        ['Typ',          r.trigger_type || '—'],
        ['Prostredie',   r.environment  || '—'],
        ['Beh',          isP ? `⚡ parallel ×${r.thread_count}` : 'serial'],
        ['Σ Trvanie',    formatDuration(r.tests_total_ms)],
        ['⏱ Čas buildu', formatDuration(r.build_duration_ms)],
        ['Jira',         isJira
            ? '<span style="color:var(--success)">✓ reportuje do Jiry</span>'
            : '<span class="muted">test run</span>'],
        ...(isJira ? [['Nová exekúcia', r.jira_new_execution == 1
            ? '<span style="color:var(--accent)">✓ vždy nová exekúcia</span>'
            : '<span class="muted">reuse existujúcej</span>']] : []),
    ];
    if (r.app_url)          items.push(['URL',              `<a href="${escHtml(r.app_url)}" target="_blank">${escHtml(r.app_url)}</a>`]);
    if (r.cucumber_tags)    items.push(['Cucumber tagy',    `<span class="mono" style="font-size:12px">${escHtml(r.cucumber_tags)}</span>`]);
    if (r.tested_feature)   items.push(['Testované features', `<span class="mono" style="font-size:12px">${escHtml(r.tested_feature)}</span>`]);
    if (r.test_properties)  items.push(['Property file',    `<span class="mono" style="font-size:12px">${escHtml(r.test_properties)}</span>`]);
    if (r.jira_cycle_ids) {
        const cycles = r.jira_cycle_ids.split(',').map(c => c.trim()).filter(Boolean);
        if (cycles.length > 0) {
            const links = cycles.map(c => {
                const url = JIRA_URL + JIRA_CYCLE_PATH.replace('{cycle}', c);
                return `<a href="${url}" target="_blank" style="display:inline-block;background:var(--accent-dim);color:var(--accent);border-radius:10px;padding:1px 8px;font-size:12px;margin:1px;text-decoration:none">🔗 ${escHtml(c)}</a>`;
            }).join(' ');
            items.push(['Jira Cycles', links]);
        }
    }
    document.getElementById('rinfo-' + runId).innerHTML = items.map(([k,v]) =>
        `<div><div style="color:var(--text-muted);font-size:10px;text-transform:uppercase;letter-spacing:.05em;margin-bottom:2px">${k}</div><div style="font-size:12px">${v}</div></div>`
    ).join('');
}

// ── Load features ────────────────────────────────────────────
async function loadFeatures(runId) {
    const container = document.getElementById('rfeat-' + runId);
    const data = await fetchJson(`api/dev_data.php?action=features&run_id=${runId}`);
    if (!data.length) {
        container.innerHTML = '<div class="empty">Žiadne features</div>';
        return;
    }
    let html = `<div style="font-size:12px;font-weight:600;color:var(--text-muted);text-transform:uppercase;letter-spacing:.05em;margin-bottom:6px">Features (${data.length})</div>
    <table style="width:100%;border-collapse:collapse;background:var(--bg2);border-radius:6px;overflow:hidden">
    <thead><tr style="background:var(--bg3)">
        <th style="padding:8px 10px;text-align:left;font-size:11px;color:var(--text-muted)"></th>
        <th style="padding:8px 10px;text-align:left;font-size:11px;color:var(--text-muted)">Feature</th>
        <th style="padding:8px 10px;text-align:left;font-size:11px;color:var(--text-muted)">Tagy</th>
        <th style="padding:8px 10px;text-align:left;font-size:11px;color:var(--text-muted)">Status</th>
        <th style="padding:8px 10px;text-align:left;font-size:11px;color:var(--text-muted)">Scenáre</th>
        <th style="padding:8px 10px;text-align:left;font-size:11px;color:var(--text-muted)">Trvanie</th>
    </tr></thead><tbody>`;

    data.forEach(f => {
        html += `
        <tr style="border-top:1px solid var(--border)">
            <td style="padding:8px 10px;width:32px">
                <button class="expand-btn" id="fbtn-${f.id}" onclick="toggleFeat(this,${f.id})">+</button>
            </td>
            <td style="padding:8px 10px">
                <div>${escHtml(f.name)}</div>
                <div class="muted mono" style="font-size:11px">${escHtml(f.file_path||'')}</div>
            </td>
            <td style="padding:8px 10px">${renderTags(f.tags)}</td>
            <td style="padding:8px 10px">${badge(f.status)}</td>
            <td style="padding:8px 10px">
                <span style="color:var(--success)">✓${f.passed_scenarios}</span>
                <span style="color:var(--danger)"> ✗${f.failed_scenarios}</span>
                / ${f.total_scenarios}
            </td>
            <td style="padding:8px 10px;white-space:nowrap">${formatDuration(f.duration_ms)}</td>
        </tr>
        <tr id="frow-${f.id}" style="display:none">
            <td colspan="99" style="padding:0;border-top:1px solid var(--accent-dim)">
                <div style="padding:10px 10px 12px 48px;background:var(--bg)">
                    <div id="fscen-${f.id}">
                        <div style="padding:10px;text-align:center">
                            <div class="spinner" style="margin:0 auto;width:18px;height:18px"></div>
                        </div>
                    </div>
                </div>
            </td>
        </tr>`;
    });
    html += '</tbody></table>';
    container.innerHTML = html;
}

async function toggleFeat(btn, featId) {
    const row  = document.getElementById('frow-' + featId);
    const open = row.style.display === 'none';
    row.style.display = open ? 'table-row' : 'none';
    btn.classList.toggle('open', open);
    if (open && !row.dataset.loaded) {
        row.dataset.loaded = '1';
        loadScenarios(featId);
    }
}

// ── Load scenarios ───────────────────────────────────────────
async function loadScenarios(featId) {
    const container = document.getElementById('fscen-' + featId);
    const data = await fetchJson(`api/dev_data.php?action=scenarios&feature_id=${featId}`);
    if (!data.length) {
        container.innerHTML = '<div class="empty" style="padding:10px">Žiadne scenáre</div>';
        return;
    }
    let html = `<div style="font-size:12px;font-weight:600;color:var(--text-muted);text-transform:uppercase;letter-spacing:.05em;margin-bottom:6px">Scenáre (${data.length})</div>
    <table style="width:100%;border-collapse:collapse;background:var(--bg3);border-radius:6px;overflow:hidden">
    <thead><tr style="background:var(--bg2)">
        <th style="padding:7px 10px;text-align:left;font-size:11px;color:var(--text-muted)"></th>
        <th style="padding:7px 10px;text-align:left;font-size:11px;color:var(--text-muted)">Scenár</th>
        <th style="padding:7px 10px;text-align:left;font-size:11px;color:var(--text-muted)">Tagy</th>
        <th style="padding:7px 10px;text-align:left;font-size:11px;color:var(--text-muted)">Status</th>
        <th style="padding:7px 10px;text-align:left;font-size:11px;color:var(--text-muted)">Stepy</th>
        <th style="padding:7px 10px;text-align:left;font-size:11px;color:var(--text-muted)">Riadok</th>
        <th style="padding:7px 10px;text-align:left;font-size:11px;color:var(--text-muted)">Trvanie</th>
    </tr></thead><tbody>`;

    data.forEach(s => {
        const scenText = [s.name, s.tags||''].join(' ').toLowerCase();
        html += `
        <tr data-scen-name="${escHtml(scenText)}" style="border-top:1px solid var(--border)">
            <td style="padding:7px 10px;width:32px">
                <button class="expand-btn" id="sbtn-${s.id}" onclick="toggleScen(this,${s.id})">+</button>
            </td>
            <td style="padding:7px 10px">
                <div>${escHtml(s.name)}</div>
                ${s.hook_error_message
                    ? `<div class="hook-error" style="margin-top:4px"><strong>⚠ ${s.hook_error_type} hook</strong>${escHtml(s.hook_error_message)}</div>`
                    : ''}
            </td>
            <td style="padding:7px 10px">${renderTags(s.tags)}</td>
            <td style="padding:7px 10px">${badge(s.status)}</td>
            <td style="padding:7px 10px">
                <span style="color:var(--success)">✓${s.passed_steps}</span>
                <span style="color:var(--danger)"> ✗${s.failed_steps}</span>
                ${s.skipped_steps>0 ? `<span style="color:var(--skip)"> ⊘${s.skipped_steps}</span>` : ''}
                / ${s.total_steps}
            </td>
            <td style="padding:7px 10px" class="mono muted">${s.line||'—'}</td>
            <td style="padding:7px 10px;white-space:nowrap">${formatDuration(s.duration_ms)}</td>
        </tr>
        <tr id="srow-${s.id}" style="display:none">
            <td colspan="99" style="padding:0;border-top:1px solid var(--border)">
                <div style="padding:8px 10px 12px 56px;background:var(--bg2)">
                    <div id="ssteps-${s.id}">
                        <div style="padding:8px;text-align:center">
                            <div class="spinner" style="margin:0 auto;width:16px;height:16px"></div>
                        </div>
                    </div>
                </div>
            </td>
        </tr>`;
    });
    html += '</tbody></table>';
    container.innerHTML = html;

    // Apply existing regex filter
    if (scenFilterRegex) {
        container.querySelectorAll('tr[data-scen-name]').forEach(row => {
            const show = scenFilterRegex.test(row.dataset.scenName);
            row.style.display = show ? '' : 'none';
            const next = row.nextElementSibling;
            if (next && !show) next.style.display = 'none';
        });
    }
}

async function toggleScen(btn, scenId) {
    const row  = document.getElementById('srow-' + scenId);
    const open = row.style.display === 'none';
    row.style.display = open ? 'table-row' : 'none';
    btn.classList.toggle('open', open);
    if (open && !row.dataset.loaded) {
        row.dataset.loaded = '1';
        loadSteps(scenId);
    }
}

// ── Load steps ───────────────────────────────────────────────
async function loadSteps(scenId) {
    const container = document.getElementById('ssteps-' + scenId);
    const data = await fetchJson(`api/dev_data.php?action=steps&scenario_id=${scenId}`);
    if (!data.length) {
        container.innerHTML = '<div class="empty" style="padding:8px">Žiadne stepy</div>';
        return;
    }
    let html = `<table style="width:100%;border-collapse:collapse"><thead>
        <tr style="background:var(--bg3)">
            <th style="padding:6px 8px;text-align:left;font-size:11px;color:var(--text-muted)">Keyword</th>
            <th style="padding:6px 8px;text-align:left;font-size:11px;color:var(--text-muted)">Step</th>
            <th style="padding:6px 8px;text-align:left;font-size:11px;color:var(--text-muted)">Status</th>
            <th style="padding:6px 8px;text-align:left;font-size:11px;color:var(--text-muted)">Riadok</th>
            <th style="padding:6px 8px;text-align:left;font-size:11px;color:var(--text-muted)">Trvanie</th>
            <th style="padding:6px 8px;text-align:left;font-size:11px;color:var(--text-muted)">📸</th>
        </tr>
    </thead><tbody>`;

    data.forEach(st => {
        html += `<tr style="border-top:1px solid var(--border)">
            <td style="padding:7px 8px;vertical-align:top"><span class="step-keyword">${escHtml(st.keyword||'')}</span></td>
            <td style="padding:7px 8px;vertical-align:top;max-width:480px">
                <div>${escHtml(st.name||'')}</div>
                ${st.translated_text && st.translated_text !== st.name
                    ? `<div class="step-translated">→ ${escHtml(st.translated_text)}</div>` : ''}
                ${st.error_message ? `<div class="error-msg">${escHtml(st.error_message)}</div>` : ''}
                ${st.stack_trace
                    ? `<span class="stack-toggle" onclick="toggleStack(this)">▼ show stack trace</span><pre class="stack-trace">${escHtml(st.stack_trace)}</pre>`
                    : ''}
            </td>
            <td style="padding:7px 8px;vertical-align:top">${badge(st.status)}</td>
            <td style="padding:7px 8px;vertical-align:top" class="mono muted">${st.line||'—'}</td>
            <td style="padding:7px 8px;vertical-align:top;white-space:nowrap">${formatDuration(st.duration_ms)}</td>
            <td style="padding:7px 8px;vertical-align:top">
                ${st.screenshot_url
                    ? `<img class="thumb" src="${escHtml(imgUrl(st.screenshot_url))}" onclick="showImage('${escHtml(imgUrl(st.screenshot_url))}')" alt="">` : ''}
                ${st.failed_screenshot_url
                    ? `<img class="thumb" src="${escHtml(imgUrl(st.failed_screenshot_url))}" onclick="showImage('${escHtml(imgUrl(st.failed_screenshot_url))}')" alt="" style="border-color:var(--danger)">` : ''}
            </td>
        </tr>`;
    });
    html += '</tbody></table>';
    container.innerHTML = html;
}

// ── Scenario filter ──────────────────────────────────────────
function applyScenFilter() {
    const raw  = document.getElementById('scen-filter').value.trim();
    const info = document.getElementById('scen-filter-info');
    try {
        scenFilterRegex = raw ? new RegExp(raw, 'i') : null;
        document.getElementById('scen-filter').style.borderColor = '';
        info.textContent = raw ? '✓ platný regex' : '';
        info.style.color = 'var(--success)';
    } catch(e) {
        const escaped = raw.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
        scenFilterRegex = new RegExp(escaped, 'i');
        document.getElementById('scen-filter').style.borderColor = 'var(--warn)';
        info.textContent = '⚠ neplatný regex, hľadám ako text';
        info.style.color = 'var(--warn)';
    }
    document.querySelectorAll('tr[data-scen-name]').forEach(row => {
        const show = !scenFilterRegex || scenFilterRegex.test(row.dataset.scenName);
        row.style.display = show ? '' : 'none';
        const next = row.nextElementSibling;
        if (next && next.id && next.id.startsWith('srow-') && !show) {
            next.style.display = 'none';
        }
    });
}

function clearScenFilter() {
    document.getElementById('scen-filter').value = '';
    document.getElementById('scen-filter-info').textContent = '';
    document.getElementById('scen-filter').style.borderColor = '';
    scenFilterRegex = null;
    document.querySelectorAll('tr[data-scen-name]').forEach(r => r.style.display = '');
}

// ── Helpers ──────────────────────────────────────────────────
function filterParams() {
    const p = new URLSearchParams(location.search);
    return {
        from:     p.get('from')     || daysAgo(14),
        to:       p.get('to')       || today(),
        project:  p.get('project')  || 'all',
        parallel: p.get('parallel') || 'all',
        jira:     p.get('jira')     || 'all',
    };
}

function renderTags(tags) {
    if (!tags) return '<span class="muted">—</span>';
    return tags.split(',').map(t =>
        `<span style="display:inline-block;background:var(--accent-dim);color:var(--accent);border-radius:10px;padding:1px 7px;font-size:11px;margin:1px">${escHtml(t.trim())}</span>`
    ).join(' ');
}

function badge(status) {
    return `<span class="badge badge-${status}">${status}</span>`;
}

function escHtml(str) {
    if (!str) return '';
    return String(str).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

// Highlight selected row style
const style = document.createElement('style');
style.textContent = 'tr[data-id].active > td { background: var(--accent-dim); }';
document.head.appendChild(style);

loadRuns();
</script>
</body>
</html>
