<?php
$projects = $db->query("SELECT DISTINCT project FROM runs ORDER BY project")->fetchAll(PDO::FETCH_COLUMN);
$params   = new class { public function __toString() { return ''; } };
$curFrom  = $_GET['from']    ?? date('Y-m-d', strtotime('-14 days'));
$curTo    = $_GET['to']      ?? date('Y-m-d');
$curProj  = $_GET['project'] ?? 'all';
?>
<div class="filters">
    <span class="filter-label">Obdobie</span>
    <button class="quick-btn" data-days="1"  onclick="setQuick(1)">24h</button>
    <button class="quick-btn" data-days="7"  onclick="setQuick(7)">7 dní</button>
    <button class="quick-btn" data-days="14" onclick="setQuick(14)">14 dní</button>
    <button class="quick-btn" data-days="30" onclick="setQuick(30)">30 dní</button>

    <div class="filter-sep"></div>

    <input type="date" id="date-from" class="filter-input" value="<?= $curFrom ?>">
    <span class="muted">—</span>
    <input type="date" id="date-to"   class="filter-input" value="<?= $curTo ?>">

    <div class="filter-sep"></div>

    <select id="project-select" class="filter-input">
        <option value="all" <?= $curProj==='all'?'selected':'' ?>>Všetky projekty</option>
        <?php foreach ($projects as $p): ?>
        <option value="<?= htmlspecialchars($p) ?>" <?= $curProj===$p?'selected':'' ?>>
            <?= htmlspecialchars($p) ?>
        </option>
        <?php endforeach; ?>
    </select>

    <button class="apply-btn" onclick="applyFilters()">Použiť</button>
</div>
<script>initFilters();</script>
