<?php
require_once 'config/db.php';
$db         = getDb();
$pageTitle  = 'Runy – Test Dashboard';
$activePage = 'runs';

$from    = $_GET['from']    ?? date('Y-m-d', strtotime('-14 days'));
$to      = $_GET['to']      ?? date('Y-m-d');
$project = $_GET['project'] ?? 'all';
$toEnd   = $to . ' 23:59:59';
$pf      = $project !== 'all' ? 'AND r.project = :project' : '';

$sql = "SELECT r.*, rm_all.meta,
    ROUND(r.passed_scenarios/NULLIF(r.total_scenarios,0)*100,1) AS success_rate
FROM runs r
LEFT JOIN (
    SELECT run_id, GROUP_CONCAT(CONCAT(meta_key,'=',meta_value) SEPARATOR '|') AS meta
    FROM run_metadata GROUP BY run_id
) rm_all ON rm_all.run_id = r.id
WHERE r.run_at BETWEEN :from AND :to $pf
ORDER BY r.run_at DESC";

$stmt = $db->prepare($sql);
$stmt->bindValue(':from', $from); $stmt->bindValue(':to', $toEnd);
if ($project !== 'all') $stmt->bindValue(':project', $project);
$stmt->execute();
$runs = $stmt->fetchAll();

include 'partials/header.php';
include 'partials/filters.php';
?>

<div class="main">
<?php if (empty($runs)): ?>
    <div class="empty"><div class="empty-icon">📭</div>Žiadne dáta pre zvolené obdobie</div>
<?php else: ?>

<?php foreach ($runs as $r):
    // Parse metadata
    $meta = [];
    if ($r['meta']) {
        foreach (explode('|', $r['meta']) as $pair) {
            if (strpos($pair,'=') !== false) {
                [$k,$v] = explode('=', $pair, 2);
                $meta[$k] = $v;
            }
        }
    }
    $dur = $r['duration_ms'] ? gmdate('H:i:s', $r['duration_ms']/1000) : '—';
    $sr  = $r['success_rate'] ?? 0;
?>
<div class="table-wrap" id="run-<?= $r['id'] ?>" style="margin-bottom:20px">
    <!-- Run header -->
    <div class="table-header" style="flex-wrap:wrap; gap:8px">
        <div class="flex">
            <button class="expand-btn" id="rbtn-<?= $r['id'] ?>"
                    onclick="toggleRow(this,'rrow-<?= $r['id'] ?>','rfeat-<?= $r['id'] ?>', () => loadFeatures(<?= $r['id'] ?>))">+</button>
            <span class="table-title">
                <?= date('d.m.Y H:i', strtotime($r['run_at'])) ?>
                &nbsp;·&nbsp;
                <span style="color:var(--accent)"><?= htmlspecialchars($r['project']) ?></span>
                &nbsp;·&nbsp; Build
                <span class="mono"><?= htmlspecialchars($r['build_number']) ?></span>
            </span>
        </div>
        <div class="flex ml-auto">
            <span class="pct <?= $sr>=80?'good':'bad' ?>"><?= $sr ?>%</span>
            <?php
                $t = max($r['total_scenarios'],1);
                $p = round($r['passed_scenarios']/$t*100);
                $f = round($r['failed_scenarios']/$t*100);
            ?>
            <div class="progress" style="width:120px">
                <div class="progress-pass" style="width:<?= $p ?>%"></div>
                <div class="progress-fail" style="width:<?= $f ?>%"></div>
                <div class="progress-skip" style="width:<?= 100-$p-$f ?>%"></div>
            </div>
        </div>
    </div>

    <!-- Run metadata grid -->
    <div class="run-meta">
        <div class="run-meta-item">
            <span class="run-meta-key">Spustil</span>
            <span class="run-meta-value"><?= htmlspecialchars($r['triggered_by'] ?? '—') ?></span>
        </div>
        <div class="run-meta-item">
            <span class="run-meta-key">Typ</span>
            <span class="run-meta-value"><?= htmlspecialchars($r['trigger_type'] ?? '—') ?></span>
        </div>
        <div class="run-meta-item">
            <span class="run-meta-key">Branch</span>
            <span class="run-meta-value mono"><?= htmlspecialchars($r['branch'] ?? '—') ?></span>
        </div>
        <div class="run-meta-item">
            <span class="run-meta-key">Prostredie</span>
            <span class="run-meta-value"><?= htmlspecialchars($r['environment'] ?? '—') ?></span>
        </div>
        <div class="run-meta-item">
            <span class="run-meta-key">Trvanie</span>
            <span class="run-meta-value"><?= $dur ?></span>
        </div>
        <?php foreach ($meta as $k => $v): ?>
        <div class="run-meta-item">
            <span class="run-meta-key"><?= htmlspecialchars($k) ?></span>
            <span class="run-meta-value"><?= htmlspecialchars($v) ?></span>
        </div>
        <?php endforeach; ?>
        <div class="run-meta-item">
            <span class="run-meta-key">Features</span>
            <span class="run-meta-value">
                <span style="color:var(--success)">✓<?= $r['passed_features'] ?></span>
                <span style="color:var(--danger)"> ✗<?= $r['failed_features'] ?></span>
                / <?= $r['total_features'] ?>
            </span>
        </div>
        <div class="run-meta-item">
            <span class="run-meta-key">Scenáre</span>
            <span class="run-meta-value">
                <span style="color:var(--success)">✓<?= $r['passed_scenarios'] ?></span>
                <span style="color:var(--danger)"> ✗<?= $r['failed_scenarios'] ?></span>
                / <?= $r['total_scenarios'] ?>
            </span>
        </div>
        <div class="run-meta-item">
            <span class="run-meta-key">Stepy</span>
            <span class="run-meta-value">
                <span style="color:var(--success)">✓<?= $r['passed_steps'] ?></span>
                <span style="color:var(--danger)"> ✗<?= $r['failed_steps'] ?></span>
                / <?= $r['total_steps'] ?>
            </span>
        </div>
    </div>

    <!-- Features nested row -->
    <tr id="rrow-<?= $r['id'] ?>" style="display:none">
        <td colspan="99" style="padding:0; border-top:2px solid var(--accent)">
            <div style="padding:12px 16px 16px 40px; background:var(--bg)">
                <div id="rfeat-<?= $r['id'] ?>">
                    <div class="spinner" style="margin:16px auto; display:block; width:24px; height:24px"></div>
                </div>
            </div>
        </td>
    </tr>
</div>
<?php endforeach; ?>
<?php endif; ?>
</div>

<script>
// For runs page, the nested rows are divs not table rows — adjust toggle
function toggleRow(btn, rowId, _, loader) {
    const row  = document.getElementById(rowId);
    const open = row.style.display !== 'block';
    row.style.display = open ? 'block' : 'none';
    btn.classList.toggle('open', open);
    if (open && loader && !row.dataset.loaded) {
        row.dataset.loaded = '1';
        loader();
    }
}

async function loadFeatures(runId) {
    const container = document.getElementById('rfeat-' + runId);
    const data = await fetchJson(`api/developer.php?action=features&run_id=${runId}`);
    if (!data.length) {
        container.innerHTML = '<div class="empty">Žiadne features</div>';
        return;
    }
    let html = `<div class="table-wrap"><div class="table-header">
        <span class="table-title">Features</span>
        <span class="table-count">${data.length}</span>
    </div><table><thead><tr>
        <th></th><th>Feature</th><th>Status</th><th>Scenáre</th><th>Trvanie</th>
    </tr></thead><tbody>`;

    data.forEach((f, i) => {
        const rowId = `frow-${runId}-${f.id}`;
        html += `<tr class="clickable-row">
            <td style="width:32px">
                <button class="expand-btn" id="fbtn-${f.id}"
                    onclick="event.stopPropagation();toggleFeat(this,'${rowId}',${f.id})">+</button>
            </td>
            <td>${escHtml(f.name)}<br><span class="muted mono" style="font-size:11px">${escHtml(f.file_path||'')}</span></td>
            <td>${badge(f.status)}</td>
            <td>
                <span style="color:var(--success)">✓${f.passed_scenarios}</span>
                <span style="color:var(--danger)"> ✗${f.failed_scenarios}</span>
                / ${f.total_scenarios}
            </td>
            <td class="nowrap">${formatDuration(f.duration_ms)}</td>
        </tr>
        <tr id="${rowId}" style="display:none">
            <td colspan="99" style="padding:0; border-top:1px solid var(--accent-dim)">
                <div style="padding:10px 12px 12px 48px; background:var(--bg2)">
                    <div id="fscen-${f.id}">
                        <div class="spinner" style="margin:12px auto; display:block; width:20px;height:20px"></div>
                    </div>
                </div>
            </td>
        </tr>`;
    });
    html += '</tbody></table></div>';
    container.innerHTML = html;
}

async function toggleFeat(btn, rowId, featId) {
    const row  = document.getElementById(rowId);
    const open = row.style.display !== 'table-row';
    row.style.display = open ? 'table-row' : 'none';
    btn.classList.toggle('open', open);
    if (open && !row.dataset.loaded) {
        row.dataset.loaded = '1';
        await loadScenarios(featId);
    }
}

async function loadScenarios(featId) {
    const container = document.getElementById('fscen-' + featId);
    const data = await fetchJson(`api/developer.php?action=scenarios&feature_id=${featId}`);
    if (!data.length) {
        container.innerHTML = '<div class="empty" style="padding:12px">Žiadne scenáre</div>';
        return;
    }
    let html = `<div class="table-wrap"><div class="table-header">
        <span class="table-title">Scenáre</span><span class="table-count">${data.length}</span>
    </div><table><thead><tr>
        <th></th><th>Scenár</th><th>Status</th><th>Stepy</th><th>Riadok</th><th>Trvanie</th>
    </tr></thead><tbody>`;

    data.forEach(s => {
        const rowId = `srow-${s.id}`;
        html += `<tr>
            <td style="width:32px">
                <button class="expand-btn" id="sbtn-${s.id}"
                    onclick="toggleScen(this,'${rowId}',${s.id})">+</button>
            </td>
            <td>${escHtml(s.name)}
                ${s.hook_error_message ? `<div class="hook-error"><strong>⚠ ${s.hook_error_type} hook zlyhal</strong>${escHtml(s.hook_error_message)}</div>` : ''}
            </td>
            <td>${badge(s.status)}</td>
            <td>
                <span style="color:var(--success)">✓${s.passed_steps}</span>
                <span style="color:var(--danger)"> ✗${s.failed_steps}</span>
                ${s.skipped_steps > 0 ? `<span style="color:var(--skip)"> ⊘${s.skipped_steps}</span>` : ''}
                / ${s.total_steps}
            </td>
            <td class="mono muted">${s.line || '—'}</td>
            <td class="nowrap">${formatDuration(s.duration_ms)}</td>
        </tr>
        <tr id="${rowId}" style="display:none">
            <td colspan="99" style="padding:0; border-top:1px solid var(--border)">
                <div style="padding:8px 10px 12px 56px; background:var(--bg3)">
                    <div id="ssteps-${s.id}">
                        <div class="spinner" style="margin:10px auto; display:block; width:18px;height:18px"></div>
                    </div>
                </div>
            </td>
        </tr>`;
    });
    html += '</tbody></table></div>';
    container.innerHTML = html;
}

async function toggleScen(btn, rowId, scenId) {
    const row  = document.getElementById(rowId);
    const open = row.style.display !== 'table-row';
    row.style.display = open ? 'table-row' : 'none';
    btn.classList.toggle('open', open);
    if (open && !row.dataset.loaded) {
        row.dataset.loaded = '1';
        await loadSteps(scenId);
    }
}

async function loadSteps(scenId) {
    const container = document.getElementById('ssteps-' + scenId);
    const data = await fetchJson(`api/developer.php?action=steps&scenario_id=${scenId}`);
    if (!data.length) {
        container.innerHTML = '<div class="empty" style="padding:10px">Žiadne stepy</div>';
        return;
    }
    let html = `<table style="width:100%; border-collapse:collapse"><thead>
        <tr style="background:var(--bg2)">
            <th style="padding:7px 10px; text-align:left; font-size:11px; color:var(--text-muted); text-transform:uppercase">Keyword</th>
            <th style="padding:7px 10px; text-align:left; font-size:11px; color:var(--text-muted); text-transform:uppercase">Step</th>
            <th style="padding:7px 10px; text-align:left; font-size:11px; color:var(--text-muted); text-transform:uppercase">Status</th>
            <th style="padding:7px 10px; text-align:left; font-size:11px; color:var(--text-muted); text-transform:uppercase">Riadok</th>
            <th style="padding:7px 10px; text-align:left; font-size:11px; color:var(--text-muted); text-transform:uppercase">Trvanie</th>
            <th style="padding:7px 10px; text-align:left; font-size:11px; color:var(--text-muted); text-transform:uppercase">📸</th>
        </tr>
    </thead><tbody>`;

    data.forEach(st => {
        const hasError = st.error_message || st.stack_trace;
        html += `<tr style="border-bottom:1px solid var(--border)">
            <td style="padding:8px 10px; vertical-align:top">
                <span class="step-keyword">${escHtml(st.keyword||'')}</span>
            </td>
            <td style="padding:8px 10px; vertical-align:top; max-width:500px">
                <div class="step-name">${escHtml(st.name||'')}</div>
                ${st.translated_text && st.translated_text !== st.name
                    ? `<div class="step-translated">→ ${escHtml(st.translated_text)}</div>` : ''}
                ${hasError ? `
                    <div class="error-msg">${escHtml(st.error_message||'')}</div>
                    ${st.stack_trace ? `
                        <span class="stack-toggle" onclick="toggleStack(this)">▼ show stack trace</span>
                        <pre class="stack-trace">${escHtml(st.stack_trace)}</pre>
                    ` : ''}
                ` : ''}
            </td>
            <td style="padding:8px 10px; vertical-align:top">${badge(st.status)}</td>
            <td style="padding:8px 10px; vertical-align:top" class="mono muted">${st.line||'—'}</td>
            <td style="padding:8px 10px; vertical-align:top; white-space:nowrap">${formatDuration(st.duration_ms)}</td>
            <td style="padding:8px 10px; vertical-align:top">
                ${st.screenshot_url ? `<img class="thumb" src="${escHtml(st.screenshot_url)}" onclick="showImage('${escHtml(st.screenshot_url)}')" alt="screenshot">` : ''}
                ${st.failed_screenshot_url ? `<img class="thumb" src="${escHtml(st.failed_screenshot_url)}" onclick="showImage('${escHtml(st.failed_screenshot_url)}')" alt="failed screenshot" style="border-color:var(--danger)">` : ''}
            </td>
        </tr>`;
    });
    html += '</tbody></table>';
    container.innerHTML = html;
}

function badge(status) {
    return `<span class="badge badge-${status}">${status}</span>`;
}

function escHtml(str) {
    if (!str) return '';
    return String(str).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}
</script>

</body>
</html>
