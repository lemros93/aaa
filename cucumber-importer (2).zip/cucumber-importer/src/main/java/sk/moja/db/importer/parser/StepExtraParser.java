package sk.moja.db.importer.parser;

import com.fasterxml.jackson.databind.ObjectMapper;
import sk.moja.db.importer.plugin.StepExtra;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;

/**
 * Číta steps-extra.ndjson a vracia mapu testStepId -> StepExtra.
 * Každý záznam obsahuje translatedText, screenshotUrl, failedScreenshotUrl.
 */
public class StepExtraParser {

    private static final Logger log = LoggerFactory.getLogger(StepExtraParser.class);
    private final ObjectMapper mapper = new ObjectMapper();

    public Map<String, StepExtra> parse(String filePath) throws IOException {
        Path path = Paths.get(filePath);
        if (!Files.exists(path)) {
            log.warn("steps-extra.ndjson not found at {}, skipping enrichment", filePath);
            return Collections.emptyMap();
        }

        Map<String, StepExtra> result = new HashMap<>();

        try (BufferedReader reader = Files.newBufferedReader(path, StandardCharsets.UTF_8)) {
            String line;
            while ((line = reader.readLine()) != null) {
                line = line.trim();
                if (line.isEmpty()) continue;
                StepExtra extra = mapper.readValue(line, StepExtra.class);
                if (extra.testStepId != null) {
                    result.put(extra.testStepId, extra);
                }
            }
        }

        log.info("Loaded {} step enrichment records from {}", result.size(), filePath);
        return result;
    }
}
