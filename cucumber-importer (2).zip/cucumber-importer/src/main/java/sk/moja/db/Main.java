package sk.moja.db;

import sk.moja.db.config.ImportConfig;
import sk.moja.db.db.DatabaseWriter;
import sk.moja.db.model.TestRun;
import sk.moja.db.parser.NdjsonParser;
import sk.moja.db.parser.StepExtraParser;
import sk.moja.db.plugin.StepExtra;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Map;

import static sk.moja.enumerators.Constants.DESTINATION;
import static sk.moja.enumerators.Constants.LOCAL_DESTINATION;

public class Main {

    private static final Logger log = LoggerFactory.getLogger(Main.class);

    public static void main(String[] args) {
        log.info("=== Cucumber NDJSON Importer ===");

        // TODO: odstraniť pred nasadením na Bamboo
        System.setProperty("db.url",          "jdbc:mysql://localhost:3306/automation");
        System.setProperty("db.user",          "marek");
        System.setProperty("db.password",      "password");
        System.setProperty("project",          "mojacsob");
        System.setProperty("branch",           "develop");
        System.setProperty("build.number",     "1");
        System.setProperty("trigger.type",     "manual");
        System.setProperty("triggered.by",     "marek");
        System.setProperty("browser",          "edge");
        System.setProperty("browser.version",  "124");

        ImportConfig config;
        try {
            config = ImportConfig.fromSystemProperties();
        } catch (IllegalArgumentException e) {
            log.error("Configuration error: {}", e.getMessage());
            log.error("Required properties: -Dndjson=... -Ddb.url=... -Ddb.user=... -Ddb.password=...");
            System.exit(1);
            return;
        }

        log.info("Project:      {}", config.project);
        log.info("Environment:  {}", config.environment);
        log.info("Branch:       {}", config.branch);
        log.info("Build:        {}", config.buildNumber);
        log.info("Triggered by: {} ({})", config.triggeredBy, config.triggerType);
        log.info("Browser:      {} {}", config.browser, config.browserVersion);
        log.info("NDJSON file:  {}", config.ndjsonPath);

        NdjsonParser    parser      = new NdjsonParser();
        StepExtraParser extraParser = new StepExtraParser();
        DatabaseWriter  writer      = null;

        try {
            Map<String, StepExtra> stepExtras = extraParser.parse(config.stepsExtraPath);
            TestRun run = parser.parse(config.ndjsonPath, stepExtras);
            writer      = new DatabaseWriter(config);
            writer.save(run, config);
            log.info("=== Import completed successfully ===");

        } catch (Exception e) {
            log.error("Import failed: {}", e.getMessage(), e);
            System.exit(2);

        } finally {
            if (writer != null) writer.close();
        }
    }
}
