package sk.moja.db.plugin;

/**
 * Jeden záznam na Gherkin step, zapísaný v AFTER_STEP hooku.
 * Párovaný s cucumber.ndjson cez testStepId.
 */
public class StepExtra {
    public String testStepId;
    public String translatedText;
    public String screenshotUrl;
    public String failedScreenshotUrl;
}
