package sk.moja.db.importer.plugin;

import com.fasterxml.jackson.databind.ObjectMapper;
import sk.moja.utils.StepContext;
import io.cucumber.plugin.EventListener;
import io.cucumber.plugin.event.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;

/**
 * Zapisuje do steps-extra.ndjson pre každý step:
 * - translatedText, screenshotUrl, failedScreenshotUrl
 *
 * Logika:
 * - PickleStepTestStep → setCurrentStepId (zapamätaj ID aktuálneho stepu)
 * - HookTestStep AFTER_STEP → screenshot je dostupný, zapíš záznam pre currentStepId
 * - SKIPPED stepy sa preskočia (žiadny screenshot nevznikol)
 *
 * Register in @CucumberOptions:
 *   plugin = {"sk.moja.db.plugin.StepEnrichmentPlugin:target/steps-extra.ndjson"}
 */
public class StepEnrichmentPlugin implements EventListener {

    private static final Logger log = LoggerFactory.getLogger(StepEnrichmentPlugin.class);

    private final ObjectMapper mapper = new ObjectMapper();
    private final Path outputPath;

    public StepEnrichmentPlugin(String outputPath) {
        this.outputPath = Paths.get(outputPath);
        initOutputFile();
    }

    @Override
    public void setEventPublisher(EventPublisher publisher) {
        publisher.registerHandlerFor(TestStepFinished.class, this::onTestStepFinished);
    }

    // -------------------------------------------------------------------------

    private void onTestStepFinished(TestStepFinished event) {
        // skipped — žiadny screenshot nevznikol, preskočíme
        if (event.getResult().getStatus().is(Status.SKIPPED)) {
            return;
        }

        // PickleStep — zapamätaj ID pre následný AFTER_STEP hook
        if (event.getTestStep() instanceof PickleStepTestStep step) {
            StepContext.setCurrentStepId(step.getId().toString());
        }

        // AFTER_STEP hook — screenshot je teraz dostupný, zapíš záznam
        if (event.getTestStep() instanceof HookTestStep hookStep) {
            if (hookStep.getHookType().equals(HookType.AFTER_STEP)) {
                StepExtra extra               = new StepExtra();
                extra.testStepId              = StepContext.getCurrentStepId();
                extra.translatedText          = StepContext.getStepNameTransformed();
                extra.screenshotUrl           = nullIfBlank(StepContext.getScreenshotPath());
                extra.failedScreenshotUrl     = nullIfBlank(StepContext.getFailedScreenshotPath());

                writeLine(extra);
            }
        }
    }

    // -------------------------------------------------------------------------

    private void initOutputFile() {
        try {
            Path parent = outputPath.getParent();
            if (parent != null) Files.createDirectories(parent);
            Files.write(outputPath, new byte[0],
                    StandardOpenOption.CREATE,
                    StandardOpenOption.TRUNCATE_EXISTING);
        } catch (IOException e) {
            log.error("StepEnrichmentPlugin: cannot create output file: {}", outputPath, e);
        }
    }

    private synchronized void writeLine(StepExtra extra) {
        try (BufferedWriter writer = Files.newBufferedWriter(
                outputPath, StandardCharsets.UTF_8, StandardOpenOption.APPEND)) {
            writer.write(mapper.writeValueAsString(extra));
            writer.newLine();
        } catch (IOException e) {
            log.error("StepEnrichmentPlugin: failed to write record for testStepId={}", extra.testStepId, e);
        }
    }

    private static String nullIfBlank(String s) {
        return (s == null || s.isBlank()) ? null : s;
    }
}
