package sk.moja.db.importer.model;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class TestRun {
    public LocalDateTime runAt;
    public long testsTotalMs;       // suma trvania vsetkych testov
    public long buildDurationMs;    // realny cas od zaciatku po koniec buildu
    public List<Feature> features = new ArrayList<>();

    // aggregations — computed after parsing
    public int totalFeatures, passedFeatures, failedFeatures;
    public int totalScenarios, passedScenarios, failedScenarios;
    public int totalSteps, passedSteps, failedSteps, skippedSteps;

    public void computeAggregations() {
        totalFeatures   = features.size();
        passedFeatures  = 0;
        failedFeatures  = 0;
        totalScenarios  = 0;
        passedScenarios = 0;
        failedScenarios = 0;
        totalSteps      = 0;
        passedSteps     = 0;
        failedSteps     = 0;
        skippedSteps    = 0;

        for (Feature f : features) {
            f.computeAggregations();

            if ("passed".equals(f.status)) passedFeatures++;
            else failedFeatures++;

            totalScenarios  += f.totalScenarios;
            passedScenarios += f.passedScenarios;
            failedScenarios += f.failedScenarios;
            totalSteps      += f.totalSteps;
            passedSteps     += f.passedSteps;
            failedSteps     += f.failedSteps;
            skippedSteps    += f.skippedSteps;
        }

        testsTotalMs = features.stream().mapToLong(f -> f.durationMs).sum();
    }
}
