package sk.moja.db.model;

public class Step {
    public String testStepId;          // direct step ID from Cucumber — used for enrichment lookup
    public String keyword;             // Given / When / Then / And / But
    public String name;                // original text from .feature file
    public String translatedText;      // resolved property values (from StepEnrichmentPlugin)
    public int line;                   // line number in .feature file
    public String status;              // passed / failed / skipped
    public long durationMs;
    public String errorMessage;
    public String stackTrace;
    public String screenshotUrl;       // per-step screenshot (optional)
    public String failedScreenshotUrl; // screenshot from @After hook, set on the failed step
}
