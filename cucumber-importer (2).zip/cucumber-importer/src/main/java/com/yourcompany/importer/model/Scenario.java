package com.yourcompany.importer.model;

import java.util.ArrayList;
import java.util.List;

public class Scenario {
    public String name;
    public String status;               // passed / failed / skipped
    public int line;                    // line number in .feature file
    public long durationMs;
    public List<Step> steps = new ArrayList<>();

    // hook failure info — populated when Before/After hook fails
    public String hookErrorMessage;
    public String hookErrorType;        // "before" / "after"

    // aggregations
    public int totalSteps, passedSteps, failedSteps, skippedSteps;

    public void computeStepAggregations() {
        totalSteps   = steps.size();
        passedSteps  = 0;
        failedSteps  = 0;
        skippedSteps = 0;
        boolean anyFailed = false;

        for (Step s : steps) {
            durationMs += s.durationMs;
            switch (s.status) {
                case "passed"  -> passedSteps++;
                case "failed"  -> { failedSteps++; anyFailed = true; }
                case "skipped" -> skippedSteps++;
            }
        }

        // hook failure overrides status even when no pickle steps failed
        if (hookErrorMessage != null) {
            status = "failed";
        } else {
            status = anyFailed ? "failed" : (skippedSteps > 0 && passedSteps == 0) ? "skipped" : "passed";
        }
    }

    public boolean isFailed() {
        return "failed".equals(status);
    }
}
