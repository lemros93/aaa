package com.yourcompany.importer.parser;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.yourcompany.importer.plugin.StepExtra;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;

/**
 * Reads steps-extra.ndjson and builds a single lookup map by testStepId.
 *
 * Two record types in the file:
 * - step record:    testStepId set → translatedText + screenshotUrl
 * - screenshot record: failedStepId set → failedScreenshotUrl
 *
 * Both are merged into the same map keyed by testStepId (or failedStepId).
 * NdjsonParser uses this map to enrich Step objects.
 */
public class StepExtraParser {

    private static final Logger log = LoggerFactory.getLogger(StepExtraParser.class);
    private final ObjectMapper mapper = new ObjectMapper();

    public Map<String, StepExtra> parse(String filePath) throws IOException {
        Path path = Paths.get(filePath);
        if (!Files.exists(path)) {
            log.warn("steps-extra.ndjson not found at {}, skipping enrichment", filePath);
            return Collections.emptyMap();
        }

        Map<String, StepExtra> result = new HashMap<>();

        try (BufferedReader reader = Files.newBufferedReader(path, StandardCharsets.UTF_8)) {
            String line;
            while ((line = reader.readLine()) != null) {
                line = line.trim();
                if (line.isEmpty()) continue;

                StepExtra extra = mapper.readValue(line, StepExtra.class);

                if (extra.testStepId != null) {
                    // step record — store by testStepId
                    result.put(extra.testStepId, extra);

                } else if (extra.failedStepId != null) {
                    // screenshot record — merge failedScreenshotUrl into existing step entry
                    StepExtra existing = result.get(extra.failedStepId);
                    if (existing != null) {
                        existing.failedScreenshotUrl = extra.failedScreenshotUrl;
                    } else {
                        // step record not yet seen (shouldn't happen, but handle gracefully)
                        result.put(extra.failedStepId, extra);
                    }
                }
            }
        }

        log.info("Loaded {} step enrichment records from {}", result.size(), filePath);
        return result;
    }
}
