package com.yourcompany.importer;

import com.yourcompany.importer.config.ImportConfig;
import com.yourcompany.importer.db.DatabaseWriter;
import com.yourcompany.importer.model.TestRun;
import com.yourcompany.importer.parser.NdjsonParser;
import com.yourcompany.importer.parser.StepExtraParser;
import com.yourcompany.importer.plugin.StepExtra;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Map;

public class Main {

    private static final Logger log = LoggerFactory.getLogger(Main.class);

    public static void main(String[] args) {
        log.info("=== Cucumber NDJSON Importer ===");

        ImportConfig config;
        try {
            config = ImportConfig.fromSystemProperties();
        } catch (IllegalArgumentException e) {
            log.error("Configuration error: {}", e.getMessage());
            log.error("Required properties: -Dndjson=... -Ddb.url=... -Ddb.user=... -Ddb.password=...");
            System.exit(1);
            return;
        }

        log.info("Project:      {}", config.project);
        log.info("Environment:  {}", config.environment);
        log.info("Branch:       {}", config.branch);
        log.info("Build:        {}", config.buildNumber);
        log.info("Triggered by: {} ({})", config.triggeredBy, config.triggerType);
        log.info("Browser:      {} {}", config.browser, config.browserVersion);
        log.info("NDJSON file:  {}", config.ndjsonPath);

        NdjsonParser    parser      = new NdjsonParser();
        StepExtraParser extraParser = new StepExtraParser();
        DatabaseWriter  writer      = null;

        try {
            Map<String, StepExtra> stepExtras = extraParser.parse(config.stepsExtraPath);
            TestRun run = parser.parse(config.ndjsonPath, stepExtras);
            writer      = new DatabaseWriter(config);
            writer.save(run, config);
            log.info("=== Import completed successfully ===");

        } catch (Exception e) {
            log.error("Import failed: {}", e.getMessage(), e);
            System.exit(2);

        } finally {
            if (writer != null) writer.close();
        }
    }
}
