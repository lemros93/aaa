package com.yourcompany.importer.plugin;

/**
 * One record per Gherkin step, written to steps-extra.ndjson in TestStepFinished.
 * Matched to cucumber.ndjson via testStepId.
 *
 * failedScreenshotUrl is written separately in TestCaseFinished (after @After hook runs).
 * It is written as a record with only failedStepId + failedScreenshotUrl set,
 * so the importer knows which step to attach it to.
 */
public class StepExtra {
    public String testStepId;          // ID of this step — primary key for lookup
    public String translatedText;      // resolved property values
    public String screenshotUrl;       // per-step screenshot (optional)

    // set only in the TestCaseFinished record — identifies which step gets the screenshot
    public String failedStepId;        // testStepId of the failed step
    public String failedScreenshotUrl; // screenshot from @After hook
}
