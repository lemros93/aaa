package com.yourcompany.importer.plugin;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.yourcompany.importer.context.StepContext;
import io.cucumber.plugin.EventListener;
import io.cucumber.plugin.event.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.Map;

/**
 * Writes two types of records to steps-extra.ndjson:
 *
 * 1. Per-step record (testStepId set) — written in TestStepFinished
 *    Contains translatedText + screenshotUrl
 *
 * 2. Failed screenshot record (failedStepId + failedScreenshotUrl set) — written in TestCaseFinished
 *    Written after @After hook runs so failedScreenshotUrl is available.
 *    failedStepId points to the step that actually failed.
 *
 * Register in @CucumberOptions:
 *   plugin = {"com.yourcompany.importer.plugin.StepEnrichmentPlugin:target/steps-extra.ndjson"}
 */
public class StepEnrichmentPlugin implements EventListener {

    private static final Logger log = LoggerFactory.getLogger(StepEnrichmentPlugin.class);

    private final ObjectMapper mapper = new ObjectMapper();
    private final Path outputPath;

    // ThreadLocal — each parallel thread tracks its own failed step ID
    private final ThreadLocal<String> failedStepId = new ThreadLocal<>();

    public StepEnrichmentPlugin(String outputPath) {
        this.outputPath = Paths.get(outputPath);
        initOutputFile();
    }

    @Override
    public void setEventPublisher(EventPublisher publisher) {
        publisher.registerHandlerFor(TestStepFinished.class, this::onTestStepFinished);
        publisher.registerHandlerFor(TestCaseFinished.class, this::onTestCaseFinished);
    }

    // -------------------------------------------------------------------------

    private void onTestStepFinished(TestStepFinished event) {
        // skip Before/After hooks — only actual Gherkin steps
        if (!(event.getTestStep() instanceof PickleStepTestStep)) return;

        PickleStepTestStep step = (PickleStepTestStep) event.getTestStep();
        String stepId = step.getId().toString();

        // remember the failed step ID so we can attach the screenshot later
        if (event.getResult().getStatus().is(Status.FAILED)) {
            failedStepId.set(stepId);
        }

        StepExtra extra      = new StepExtra();
        extra.testStepId     = stepId;
        extra.translatedText = StepContext.getCurrentStepName();
        extra.screenshotUrl  = nullIfBlank(StepContext.getScreenshotUrl());

        writeLine(extra);
    }

    private void onTestCaseFinished(TestCaseFinished event) {
        // @After has already run — failedScreenshotUrl is now available
        String url    = nullIfBlank(StepContext.getFailedScreenshotUrl());
        String stepId = failedStepId.get();

        // only write if there is a screenshot AND a failed step to attach it to
        if (url == null || stepId == null) {
            failedStepId.remove();
            return;
        }

        StepExtra extra          = new StepExtra();
        extra.failedStepId       = stepId;
        extra.failedScreenshotUrl = url;

        writeLine(extra);
        failedStepId.remove();
    }

    // -------------------------------------------------------------------------

    private void initOutputFile() {
        try {
            Path parent = outputPath.getParent();
            if (parent != null) Files.createDirectories(parent);
            Files.write(outputPath, new byte[0],
                    StandardOpenOption.CREATE,
                    StandardOpenOption.TRUNCATE_EXISTING);
        } catch (IOException e) {
            log.error("StepEnrichmentPlugin: cannot create output file: {}", outputPath, e);
        }
    }

    private synchronized void writeLine(StepExtra extra) {
        try (BufferedWriter writer = Files.newBufferedWriter(
                outputPath, StandardCharsets.UTF_8, StandardOpenOption.APPEND)) {
            writer.write(mapper.writeValueAsString(extra));
            writer.newLine();
        } catch (IOException e) {
            log.error("StepEnrichmentPlugin: failed to write record", e);
        }
    }

    private static String nullIfBlank(String s) {
        return (s == null || s.isBlank()) ? null : s;
    }
}
