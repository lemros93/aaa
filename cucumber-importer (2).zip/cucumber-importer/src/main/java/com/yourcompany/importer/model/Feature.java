package com.yourcompany.importer.model;

import java.util.ArrayList;
import java.util.List;

public class Feature {
    public String name;
    public String filePath;
    public String status;           // passed / failed / skipped
    public long durationMs;
    public List<Scenario> scenarios = new ArrayList<>();

    // aggregations
    public int totalScenarios, passedScenarios, failedScenarios;
    public int totalSteps, passedSteps, failedSteps, skippedSteps;

    public void computeAggregations() {
        totalScenarios  = scenarios.size();
        passedScenarios = 0;
        failedScenarios = 0;
        totalSteps      = 0;
        passedSteps     = 0;
        failedSteps     = 0;
        skippedSteps    = 0;
        boolean anyFailed = false;

        for (Scenario s : scenarios) {
            if ("passed".equals(s.status)) passedScenarios++;
            else {
                failedScenarios++;
                anyFailed = true;
            }

            totalSteps   += s.totalSteps;
            passedSteps  += s.passedSteps;
            failedSteps  += s.failedSteps;
            skippedSteps += s.skippedSteps;
            durationMs   += s.durationMs;
        }

        status = anyFailed ? "failed" : "passed";
    }
}
