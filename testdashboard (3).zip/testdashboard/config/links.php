<?php
// ── External link configuration ─────────────────────────────
// Configure your Bamboo and Jira URLs here

// Bamboo base URL — build link will be: BAMBOO_URL/browse/{build_number}
define('BAMBOO_URL', 'https://bamboo.vasa-firma.sk');

// Jira base URL — test cycle link will be: JIRA_URL/projects/{project}/test-cycles/{cycle_id}
// Adjust the path pattern to match your Jira version
define('JIRA_URL',   'https://jira.vasa-firma.sk');

// Jira test cycle path pattern — {cycle} will be replaced with cycle ID
define('JIRA_CYCLE_PATH', '/projects/TEST/test-cycles/{cycle}');
