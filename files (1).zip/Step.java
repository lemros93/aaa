package com.yourcompany.importer.model;

public class Step {
    public int order;
    public String keyword;            // Given / When / Then / And / But
    public String name;               // original text from .feature file
    public String translatedText;     // resolved property values (from StepEnrichmentPlugin)
    public String status;             // passed / failed / skipped
    public long durationMs;
    public String errorMessage;
    public String stackTrace;
    public String screenshotUrl;      // per-step screenshot (optional)
    public String failedScreenshotUrl;// screenshot on failure (optional)
}
