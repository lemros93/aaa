<?php
require_once 'config/db.php';
$db         = getDb();
$pageTitle  = 'Developer – Test Dashboard';
$activePage = 'developer';

include 'partials/header.php';
include 'partials/filters.php';
?>

<div class="main">

<!-- Runs table -->
<div class="table-wrap" id="tbl-runs">
    <div class="table-header">
        <span class="table-title">Runy</span>
        <span class="table-count" id="runs-count"></span>
    </div>
    <div id="runs-body">
        <div class="empty"><div class="spinner" style="margin:0 auto 8px; display:block; width:24px;height:24px"></div>Načítavam...</div>
    </div>
</div>

<!-- Features table (hidden until run selected) -->
<div class="table-wrap" id="tbl-features" style="display:none">
    <div class="table-header">
        <span class="table-title">Features</span>
        <span class="table-count" id="features-count"></span>
        <button class="expand-btn ml-auto" title="Zavrieť" onclick="closeSection('features')">✕</button>
    </div>
    <div id="features-body"></div>
</div>

<!-- Scenarios table (hidden until feature selected) -->
<div class="table-wrap" id="tbl-scenarios" style="display:none">
    <div class="table-header">
        <span class="table-title">Scenáre</span>
        <span class="table-count" id="scenarios-count"></span>
        <button class="expand-btn ml-auto" title="Zavrieť" onclick="closeSection('scenarios')">✕</button>
    </div>
    <div id="scenarios-body"></div>
</div>

<!-- Steps table (hidden until scenario selected) -->
<div class="table-wrap" id="tbl-steps" style="display:none">
    <div class="table-header">
        <span class="table-title">Stepy</span>
        <span class="table-count" id="steps-count"></span>
        <button class="expand-btn ml-auto" title="Zavrieť" onclick="closeSection('steps')">✕</button>
    </div>
    <div id="steps-body"></div>
</div>

</div><!-- .main -->

<script>
const fp = filterParams();

// ── Active row tracking ──────────────────────────────────────
let activeRun = null, activeFeat = null, activeScen = null;

function setActive(tbody, id) {
    tbody.querySelectorAll('tr.selected').forEach(r => r.classList.remove('selected'));
    const row = tbody.querySelector(`tr[data-id="${id}"]`);
    if (row) row.classList.add('selected');
}

// ── Load runs ────────────────────────────────────────────────
async function loadRuns() {
    const data = await fetchJson(`api/dev_data.php?action=runs&from=${fp.from}&to=${fp.to}&project=${fp.project}`);
    document.getElementById('runs-count').textContent = data.length + ' runov';
    if (!data.length) {
        document.getElementById('runs-body').innerHTML = '<div class="empty"><div class="empty-icon">📭</div>Žiadne dáta</div>';
        return;
    }
    let html = `<table><thead><tr>
        <th>Dátum</th><th>Projekt</th><th>Build</th><th>Branch</th>
        <th>Scenáre ✓/✗</th><th>Úspešnosť</th>
    </tr></thead><tbody id="runs-tbody">`;
    data.forEach(r => {
        html += `<tr data-id="${r.id}" class="clickable-row" onclick="selectRun(${r.id}, this)">
            <td class="nowrap">${formatDate(r.run_at)}</td>
            <td>${escHtml(r.project)}</td>
            <td class="mono">${escHtml(r.build_number)}</td>
            <td class="mono muted">${escHtml(r.branch||'—')}</td>
            <td>
                <span style="color:var(--success)">✓${r.passed_scenarios}</span>
                <span style="color:var(--danger)"> ✗${r.failed_scenarios}</span>
                / ${r.total_scenarios}
            </td>
            <td><span class="pct ${(r.success_rate||0)>=80?'good':'bad'}">${r.success_rate||0}%</span></td>
        </tr>`;
    });
    html += '</tbody></table>';
    document.getElementById('runs-body').innerHTML = html;
}

// ── Select run → load features ───────────────────────────────
async function selectRun(runId, rowEl) {
    activeRun = runId; activeFeat = null; activeScen = null;
    setActive(document.getElementById('runs-tbody'), runId);
    closeSection('scenarios'); closeSection('steps');
    document.getElementById('tbl-features').style.display = 'block';
    document.getElementById('features-body').innerHTML = loading();

    const data = await fetchJson(`api/dev_data.php?action=features&run_id=${runId}`);
    document.getElementById('features-count').textContent = data.length + ' features';
    if (!data.length) {
        document.getElementById('features-body').innerHTML = '<div class="empty">Žiadne features</div>';
        return;
    }
    let html = `<table><thead><tr>
        <th>Feature</th><th>Status</th><th>Scenáre ✓/✗</th><th>Trvanie</th>
    </tr></thead><tbody id="features-tbody">`;
    data.forEach(f => {
        html += `<tr data-id="${f.id}" class="clickable-row" onclick="selectFeature(${f.id}, this)">
            <td>
                <div>${escHtml(f.name)}</div>
                <div class="muted mono" style="font-size:11px">${escHtml(f.file_path||'')}</div>
            </td>
            <td>${badge(f.status)}</td>
            <td>
                <span style="color:var(--success)">✓${f.passed_scenarios}</span>
                <span style="color:var(--danger)"> ✗${f.failed_scenarios}</span>
                / ${f.total_scenarios}
            </td>
            <td class="nowrap">${formatDuration(f.duration_ms)}</td>
        </tr>`;
    });
    html += '</tbody></table>';
    document.getElementById('features-body').innerHTML = html;
    document.getElementById('tbl-features').scrollIntoView({behavior:'smooth', block:'nearest'});
}

// ── Select feature → load scenarios ─────────────────────────
async function selectFeature(featId, rowEl) {
    activeFeat = featId; activeScen = null;
    setActive(document.getElementById('features-tbody'), featId);
    closeSection('steps');
    document.getElementById('tbl-scenarios').style.display = 'block';
    document.getElementById('scenarios-body').innerHTML = loading();

    const data = await fetchJson(`api/dev_data.php?action=scenarios&feature_id=${featId}`);
    document.getElementById('scenarios-count').textContent = data.length + ' scenárov';
    if (!data.length) {
        document.getElementById('scenarios-body').innerHTML = '<div class="empty">Žiadne scenáre</div>';
        return;
    }
    let html = `<table><thead><tr>
        <th>Scenár</th><th>Status</th><th>Stepy ✓/✗</th><th>Riadok</th><th>Trvanie</th>
    </tr></thead><tbody id="scenarios-tbody">`;
    data.forEach(s => {
        html += `<tr data-id="${s.id}" class="clickable-row" onclick="selectScenario(${s.id}, this)">
            <td>
                <div>${escHtml(s.name)}</div>
                ${s.hook_error_message ? `<div class="hook-error" style="margin-top:4px"><strong>⚠ ${s.hook_error_type} hook</strong>${escHtml(s.hook_error_message)}</div>` : ''}
            </td>
            <td>${badge(s.status)}</td>
            <td>
                <span style="color:var(--success)">✓${s.passed_steps}</span>
                <span style="color:var(--danger)"> ✗${s.failed_steps}</span>
                ${s.skipped_steps>0 ? `<span style="color:var(--skip)"> ⊘${s.skipped_steps}</span>` : ''}
                / ${s.total_steps}
            </td>
            <td class="mono muted">${s.line||'—'}</td>
            <td class="nowrap">${formatDuration(s.duration_ms)}</td>
        </tr>`;
    });
    html += '</tbody></table>';
    document.getElementById('scenarios-body').innerHTML = html;
    document.getElementById('tbl-scenarios').scrollIntoView({behavior:'smooth', block:'nearest'});
}

// ── Select scenario → load steps ─────────────────────────────
async function selectScenario(scenId, rowEl) {
    activeScen = scenId;
    setActive(document.getElementById('scenarios-tbody'), scenId);
    document.getElementById('tbl-steps').style.display = 'block';
    document.getElementById('steps-body').innerHTML = loading();

    const data = await fetchJson(`api/dev_data.php?action=steps&scenario_id=${scenId}`);
    document.getElementById('steps-count').textContent = data.length + ' stepov';
    if (!data.length) {
        document.getElementById('steps-body').innerHTML = '<div class="empty">Žiadne stepy</div>';
        return;
    }
    let html = `<table><thead><tr>
        <th>Keyword</th><th>Step</th><th>Status</th><th>Riadok</th><th>Trvanie</th><th>📸</th>
    </tr></thead><tbody>`;
    data.forEach(st => {
        html += `<tr>
            <td style="vertical-align:top"><span class="step-keyword">${escHtml(st.keyword||'')}</span></td>
            <td style="vertical-align:top; max-width:520px">
                <div class="step-name">${escHtml(st.name||'')}</div>
                ${st.translated_text && st.translated_text !== st.name
                    ? `<div class="step-translated">→ ${escHtml(st.translated_text)}</div>` : ''}
                ${st.error_message ? `<div class="error-msg">${escHtml(st.error_message)}</div>` : ''}
                ${st.stack_trace ? `
                    <span class="stack-toggle" onclick="toggleStack(this)">▼ show stack trace</span>
                    <pre class="stack-trace">${escHtml(st.stack_trace)}</pre>` : ''}
            </td>
            <td style="vertical-align:top">${badge(st.status)}</td>
            <td style="vertical-align:top" class="mono muted">${st.line||'—'}</td>
            <td style="vertical-align:top; white-space:nowrap">${formatDuration(st.duration_ms)}</td>
            <td style="vertical-align:top">
                ${st.screenshot_url ? `<img class="thumb" src="${escHtml(imgUrl(st.screenshot_url))}" onclick="showImage('${escHtml(imgUrl(st.screenshot_url))}')" alt="screenshot">` : ''}
                ${st.failed_screenshot_url ? `<img class="thumb" src="${escHtml(imgUrl(st.failed_screenshot_url))}" onclick="showImage('${escHtml(imgUrl(st.failed_screenshot_url))}')" alt="failed screenshot" style="border-color:var(--danger)">` : ''}
            </td>
        </tr>`;
    });
    html += '</tbody></table>';
    document.getElementById('steps-body').innerHTML = html;
    document.getElementById('tbl-steps').scrollIntoView({behavior:'smooth', block:'nearest'});
}

// ── Helpers ──────────────────────────────────────────────────
function closeSection(name) {
    const map = {features:'tbl-features', scenarios:'tbl-scenarios', steps:'tbl-steps'};
    if (name === 'features') { closeSection('scenarios'); closeSection('steps'); }
    if (name === 'scenarios') closeSection('steps');
    document.getElementById(map[name]).style.display = 'none';
}

function loading() {
    return '<div class="empty"><div class="spinner" style="margin:0 auto 8px; display:block; width:20px;height:20px"></div>Načítavam...</div>';
}

function badge(status) {
    return `<span class="badge badge-${status}">${status}</span>`;
}

function escHtml(str) {
    if (!str) return '';
    return String(str).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

// Highlight selected rows
const style = document.createElement('style');
style.textContent = 'tr.selected { background: var(--accent-dim) !important; }';
document.head.appendChild(style);

// Init
loadRuns();
</script>

</body>
</html>
