<?php
require_once 'config/db.php';
$db         = getDb();
$pageTitle  = 'MTTR / MTBF – Test Dashboard';
$activePage = 'mttr';

$from     = $_GET['from']     ?? date('Y-m-d', strtotime('-60 days'));
$to       = $_GET['to']       ?? date('Y-m-d');
$project  = $_GET['project']  ?? 'all';
$parallel = $_GET['parallel'] ?? 'all';
$jira     = $_GET['jira']     ?? 'all';
$toEnd    = $to . ' 23:59:59';

$filters = ['r.run_at BETWEEN :from AND :to'];
$params  = [':from' => $from, ':to' => $toEnd];
if ($project  !== 'all') { $filters[] = 'r.project = :project';        $params[':project']  = $project; }
if ($parallel !== 'all') { $filters[] = 'r.parallel_mode = :parallel'; $params[':parallel'] = $parallel; }
if ($jira     !== 'all') { $filters[] = 'r.jira_reporting = :jira';    $params[':jira']     = (int)($jira === 'yes'); }
$where = 'WHERE ' . implode(' AND ', $filters);

$sql = "SELECT
    f.name          AS feature_name,
    s.name          AS scenario_name,
    s.tags,
    r.run_at,
    s.status
FROM scenarios s
JOIN features f ON f.id = s.feature_id
JOIN runs r     ON r.id = f.run_id
$where
ORDER BY f.name, s.name, r.run_at ASC";

$stmt = $db->prepare($sql);
foreach ($params as $k => $v) $stmt->bindValue($k, $v);
$stmt->execute();
$rows = $stmt->fetchAll();

// Group by scenario
$scenData = [];
foreach ($rows as $row) {
    $key = $row['feature_name'] . '|||' . $row['scenario_name'];
    if (!isset($scenData[$key])) {
        $scenData[$key] = ['feature' => $row['feature_name'], 'scenario' => $row['scenario_name'], 'tags' => $row['tags'], 'runs' => []];
    }
    $scenData[$key]['runs'][] = ['at' => $row['run_at'], 'status' => $row['status']];
}

// Compute MTTR and MTBF
$results = [];
foreach ($scenData as $data) {
    $runs = $data['runs'];
    if (count($runs) < 2) continue;

    $failCount = 0;
    $mttrValues = [];
    $mtbfValues = [];
    $lastFailAt = null;
    $prevFailAt = null;

    foreach ($runs as $run) {
        if ($run['status'] === 'failed') {
            $failCount++;
            if ($lastFailAt === null) $lastFailAt = new DateTime($run['at']);
            if ($prevFailAt !== null) {
                $diff = (new DateTime($run['at']))->getTimestamp() - $prevFailAt->getTimestamp();
                $mtbfValues[] = round($diff / 3600, 1);
            }
            $prevFailAt = new DateTime($run['at']);
        } elseif ($run['status'] === 'passed' && $lastFailAt !== null) {
            $diff = (new DateTime($run['at']))->getTimestamp() - $lastFailAt->getTimestamp();
            $mttrValues[] = round($diff / 3600, 1);
            $lastFailAt = null;
        }
    }

    if ($failCount === 0) continue;

    $results[] = [
        'feature'       => $data['feature'],
        'scenario'      => $data['scenario'],
        'tags'          => $data['tags'],
        'total_runs'    => count($runs),
        'fail_count'    => $failCount,
        'fail_rate'     => round($failCount / count($runs) * 100, 1),
        'mttr_h'        => count($mttrValues) > 0 ? round(array_sum($mttrValues)/count($mttrValues), 1) : null,
        'mtbf_h'        => count($mtbfValues) > 0 ? round(array_sum($mtbfValues)/count($mtbfValues), 1) : null,
        'still_failing' => $lastFailAt !== null,
    ];
}

usort($results, fn($a, $b) => ($b['mttr_h'] ?? -1) <=> ($a['mttr_h'] ?? -1));

include 'partials/header.php';
include 'partials/filters.php';
?>

<div class="main">

<div class="cards" style="margin-bottom:20px">
    <div class="card">
        <div class="card-label">MTTR</div>
        <div class="card-value accent" style="font-size:18px">Mean Time To Recovery</div>
        <div class="card-sub">Priemerný čas od prvého pádu po opravu (hodiny)</div>
    </div>
    <div class="card">
        <div class="card-label">MTBF</div>
        <div class="card-value accent" style="font-size:18px">Mean Time Between Failures</div>
        <div class="card-sub">Priemerný čas medzi dvoma po sebe nasledujúcimi pádmi (hodiny)</div>
    </div>
    <div class="card">
        <div class="card-label">Stále padá</div>
        <div class="card-value danger"><?= count(array_filter($results, fn($r) => $r['still_failing'])) ?></div>
        <div class="card-sub">scenárov bez recovery v zvolenom období</div>
    </div>
</div>

<div class="table-wrap">
    <div class="table-header">
        <span class="table-title">🔧 MTTR / MTBF per scenár</span>
        <span class="table-count" id="mttr-count"><?= count($results) ?> scenárov s pádmi</span>
        <div class="flex ml-auto" style="gap:6px">
            <input type="text" id="mttr-search" class="filter-input" placeholder="🔍 Filter..."
                   style="width:220px" oninput="filterTable()">
            <button class="quick-btn active" data-sort="mttr" onclick="sortTable(this)">↕ MTTR</button>
            <button class="quick-btn"        data-sort="mtbf" onclick="sortTable(this)">↕ MTBF</button>
            <button class="quick-btn"        data-sort="fail" onclick="sortTable(this)">↕ Pády</button>
        </div>
    </div>
    <?php if (empty($results)): ?>
        <div class="empty"><div class="empty-icon">✅</div>Žiadne opakujúce sa zlyhania</div>
    <?php else: ?>
    <table>
        <thead>
            <tr>
                <th>Scenár</th><th>Tagy</th><th>Runy</th><th>Pády</th>
                <th>Miera zlyhania</th>
                <th title="Priem. čas od pádu po opravu">MTTR (h)</th>
                <th title="Priem. čas medzi pádmi">MTBF (h)</th>
                <th>Stav</th>
            </tr>
        </thead>
        <tbody id="mttr-tbody">
        <?php foreach ($results as $r):
            $rateColor = $r['fail_rate'] >= 75 ? 'var(--danger)' : ($r['fail_rate'] >= 40 ? 'var(--warn)' : 'var(--text-muted)');
            $mttrColor = $r['mttr_h'] === null ? 'var(--text-muted)' : ($r['mttr_h'] > 24 ? 'var(--danger)' : ($r['mttr_h'] > 8 ? 'var(--warn)' : 'var(--success)'));
        ?>
            <tr data-search="<?= htmlspecialchars(strtolower($r['scenario'] . ' ' . $r['feature'] . ' ' . $r['tags'])) ?>"
                data-mttr="<?= $r['mttr_h'] ?? 9999 ?>"
                data-mtbf="<?= $r['mtbf_h'] ?? 9999 ?>"
                data-fail="<?= $r['fail_count'] ?>">
                <td>
                    <div><?= htmlspecialchars($r['scenario']) ?></div>
                    <div class="muted" style="font-size:11px"><?= htmlspecialchars($r['feature']) ?></div>
                </td>
                <td><?php
                    if ($r['tags']) {
                        foreach (explode(',', $r['tags']) as $tag)
                            echo '<span style="display:inline-block;background:var(--accent-dim);color:var(--accent);border-radius:10px;padding:1px 7px;font-size:11px;margin:1px">' . htmlspecialchars(trim($tag)) . '</span>';
                    } else echo '<span class="muted">—</span>';
                ?></td>
                <td><?= $r['total_runs'] ?></td>
                <td style="color:var(--danger);font-weight:600"><?= $r['fail_count'] ?>×</td>
                <td><span style="color:<?= $rateColor ?>;font-weight:600"><?= $r['fail_rate'] ?>%</span></td>
                <td>
                    <?php if ($r['mttr_h'] === null): ?>
                        <span class="muted" title="Scenár sa ešte neopravil">∞</span>
                    <?php else: ?>
                        <span style="color:<?= $mttrColor ?>;font-weight:600"><?= $r['mttr_h'] ?>h</span>
                    <?php endif; ?>
                </td>
                <td><?= $r['mtbf_h'] !== null ? $r['mtbf_h'] . 'h' : '<span class="muted">—</span>' ?></td>
                <td>
                    <?php if ($r['still_failing']): ?>
                        <span class="badge badge-failed">padá</span>
                    <?php else: ?>
                        <span class="badge badge-passed">OK</span>
                    <?php endif; ?>
                </td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    <?php endif; ?>
</div>
</div>

<script>
function filterTable() {
    const q = document.getElementById('mttr-search').value.toLowerCase();
    let visible = 0;
    document.querySelectorAll('#mttr-tbody tr').forEach(row => {
        const show = !q || row.dataset.search.includes(q);
        row.style.display = show ? '' : 'none';
        if (show) visible++;
    });
    document.getElementById('mttr-count').textContent = visible + ' scenárov s pádmi';
}

let sortDir = {};
function sortTable(btn) {
    document.querySelectorAll('.quick-btn[data-sort]').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    const col   = btn.dataset.sort;
    sortDir[col] = !sortDir[col];
    const tbody = document.getElementById('mttr-tbody');
    const rows  = Array.from(tbody.querySelectorAll('tr'));
    rows.sort((a, b) => {
        const av = parseFloat(a.dataset[col]) || 0;
        const bv = parseFloat(b.dataset[col]) || 0;
        return sortDir[col] ? av - bv : bv - av;
    });
    rows.forEach(r => tbody.appendChild(r));
}
</script>
</body>
</html>
