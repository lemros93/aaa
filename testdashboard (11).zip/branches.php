<?php
require_once 'config/db.php';
require_once 'config/links.php';
$db         = getDb();
$pageTitle  = 'Porovnanie branchí – Test Dashboard';
$activePage = 'branches';

$from     = $_GET['from']     ?? date('Y-m-d', strtotime('-30 days'));
$to       = $_GET['to']       ?? date('Y-m-d');
$project  = $_GET['project']  ?? 'all';
$parallel = $_GET['parallel'] ?? 'all';
$jira     = $_GET['jira']     ?? 'all';
$toEnd    = $to . ' 23:59:59';

$filters = ['r.run_at BETWEEN :from AND :to'];
$params  = [':from' => $from, ':to' => $toEnd];
if ($project  !== 'all') { $filters[] = 'r.project = :project';        $params[':project']  = $project; }
if ($parallel !== 'all') { $filters[] = 'r.parallel_mode = :parallel'; $params[':parallel'] = $parallel; }
if ($jira     !== 'all') { $filters[] = 'r.jira_reporting = :jira';    $params[':jira']     = (int)($jira === 'yes'); }
$where = 'WHERE ' . implode(' AND ', $filters);

$sql = "SELECT
    r.branch,
    COUNT(DISTINCT r.id)                                                    AS run_count,
    MAX(r.run_at)                                                           AS last_run,
    ROUND(AVG(r.passed_scenarios/NULLIF(r.total_scenarios,0)*100), 1)      AS avg_success,
    SUM(r.passed_scenarios)                                                 AS total_passed,
    SUM(r.failed_scenarios)                                                 AS total_failed,
    SUM(r.total_scenarios)                                                  AS total_scenarios,
    MAX(r.commit_hash)                                                      AS last_commit
FROM runs r $where
GROUP BY r.branch
ORDER BY last_run DESC";

$stmt = $db->prepare($sql);
foreach ($params as $k => $v) $stmt->bindValue($k, $v);
$stmt->execute();
$branches = $stmt->fetchAll();

include 'partials/header.php';
include 'partials/filters.php';
?>

<div class="main">

<!-- Branch overview -->
<div class="table-wrap" style="margin-bottom:20px">
    <div class="table-header">
        <span class="table-title">🌿 Prehľad branchí</span>
        <span class="table-count"><?= count($branches) ?> branchí</span>
    </div>
    <?php if (empty($branches)): ?>
        <div class="empty"><div class="empty-icon">📭</div>Žiadne dáta</div>
    <?php else: ?>
    <table>
        <thead>
            <tr>
                <th>Branch</th><th>Posledný commit</th><th>Posledný run</th>
                <th>Runy</th><th>Scenáre ✓/✗</th><th>Priem. úspešnosť</th><th>Trend</th>
            </tr>
        </thead>
        <tbody>
        <?php foreach ($branches as $b):
            $rate   = $b['avg_success'];
            $color  = $rate >= 80 ? 'var(--success)' : ($rate >= 50 ? 'var(--warn)' : 'var(--danger)');
            $commit = $b['last_commit'] ? substr($b['last_commit'], 0, 8) : '—';
            $total  = max($b['total_scenarios'], 1);
            $pct    = (int)round($b['total_passed']/$total*100);
            $fpct   = (int)round($b['total_failed']/$total*100);
        ?>
            <tr>
                <td class="mono" style="font-weight:600"><?= htmlspecialchars($b['branch']) ?></td>
                <td class="mono muted"><?= $commit ?></td>
                <td class="nowrap muted"><?= date('d.m.Y H:i', strtotime($b['last_run'])) ?></td>
                <td><?= $b['run_count'] ?></td>
                <td>
                    <span style="color:var(--success)">✓<?= $b['total_passed'] ?></span>
                    <span style="color:var(--danger)"> ✗<?= $b['total_failed'] ?></span>
                    / <?= $b['total_scenarios'] ?>
                </td>
                <td><span style="color:<?= $color ?>;font-weight:600"><?= $rate ?>%</span></td>
                <td style="min-width:100px">
                    <div class="progress">
                        <div class="progress-pass" style="width:<?= $pct ?>%"></div>
                        <div class="progress-fail" style="width:<?= $fpct ?>%"></div>
                    </div>
                </td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    <?php endif; ?>
</div>

<!-- Branch A vs B comparison -->
<div class="table-wrap">
    <div class="table-header" style="flex-wrap:wrap;gap:8px">
        <span class="table-title">⚖️ Porovnanie branchí</span>
        <div class="flex" style="gap:8px;flex-wrap:wrap">
            <select id="branch-a" class="filter-input">
                <option value="">— Branch A —</option>
                <?php foreach ($branches as $b): ?>
                <option value="<?= htmlspecialchars($b['branch']) ?>"><?= htmlspecialchars($b['branch']) ?></option>
                <?php endforeach; ?>
            </select>
            <span class="muted">vs</span>
            <select id="branch-b" class="filter-input">
                <option value="">— Branch B —</option>
                <?php foreach ($branches as $b): ?>
                <option value="<?= htmlspecialchars($b['branch']) ?>"><?= htmlspecialchars($b['branch']) ?></option>
                <?php endforeach; ?>
            </select>
            <button class="apply-btn" onclick="compareBranches()">Porovnať</button>
        </div>
    </div>
    <div id="branch-compare-body">
        <div class="empty"><div class="empty-icon">🌿</div>Vyber dve branche a klikni Porovnať</div>
    </div>
</div>

</div>

<script>
const fp = filterParams();

async function compareBranches() {
    const bA = document.getElementById('branch-a').value;
    const bB = document.getElementById('branch-b').value;
    if (!bA || !bB)  { alert('Vyber obe branche'); return; }
    if (bA === bB)   { alert('Vyber dve rôzne branche'); return; }

    document.getElementById('branch-compare-body').innerHTML =
        '<div class="empty"><div class="spinner" style="margin:0 auto 8px;display:block;width:24px;height:24px"></div>Načítavam...</div>';

    const [runsA, runsB] = await Promise.all([
        fetchJson(`api/dev_data.php?action=runs&from=${fp.from}&to=${fp.to}&project=${fp.project}&branch=${encodeURIComponent(bA)}`),
        fetchJson(`api/dev_data.php?action=runs&from=${fp.from}&to=${fp.to}&project=${fp.project}&branch=${encodeURIComponent(bB)}`)
    ]);

    if (!runsA.length || !runsB.length) {
        document.getElementById('branch-compare-body').innerHTML =
            '<div class="empty">Jedna z branchí nemá žiadne runy v zvolenom období</div>';
        return;
    }

    const runA = runsA[0];
    const runB = runsB[0];

    const [featA, featB] = await Promise.all([
        fetchJson(`api/dev_data.php?action=features&run_id=${runA.id}`),
        fetchJson(`api/dev_data.php?action=features&run_id=${runB.id}`)
    ]);

    const [mapA, mapB] = await Promise.all([buildMap(featA), buildMap(featB)]);

    const allKeys = new Set([...mapA.keys(), ...mapB.keys()]);
    let fixed = 0, broken = 0, stillFail = 0;
    let rows = [];

    for (const key of allKeys) {
        const sa = mapA.get(key), sb = mapB.get(key);
        const stA = sa ? sa.status : 'missing';
        const stB = sb ? sb.status : 'missing';
        let change, cls;
        if      (stA==='failed' && stB==='passed') { change='✅ Opravené v B';  cls='fixed';  fixed++; }
        else if (stA==='passed' && stB==='failed') { change='❌ Padá v B';      cls='broken'; broken++; }
        else if (stA==='failed' && stB==='failed') { change='🔁 Padá v oboch';  cls='fail';   stillFail++; }
        else if (stB==='missing')                  { change='🗑 Len v A';        cls='muted'; }
        else if (stA==='missing')                  { change='🆕 Len v B';        cls='accent'; }
        else                                        { change='✓ OK';             cls='pass'; }
        const [feat, scen] = key.split('|||');
        const s = sb || sa;
        rows.push({change, cls, feat, scen, stA, stB, tags: s?.tags});
    }

    const rateA = Math.round(runsA.reduce((s,r)=>s+(r.success_rate||0),0)/runsA.length);
    const rateB = Math.round(runsB.reduce((s,r)=>s+(r.success_rate||0),0)/runsB.length);

    let html = `
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px;padding:16px;border-bottom:1px solid var(--border)">
        <div style="text-align:center">
            <div style="font-size:12px;color:var(--text-muted);margin-bottom:4px">Branch A: <strong>${escHtml(bA)}</strong></div>
            <div style="font-size:28px;font-weight:700;color:${rateA>=80?'var(--success)':'var(--danger)'}">${rateA}%</div>
            <div style="font-size:12px;color:var(--text-muted)">${runsA.length} runov · Build ${escHtml(runA.build_number)}</div>
        </div>
        <div style="text-align:center">
            <div style="font-size:12px;color:var(--text-muted);margin-bottom:4px">Branch B: <strong>${escHtml(bB)}</strong></div>
            <div style="font-size:28px;font-weight:700;color:${rateB>=80?'var(--success)':'var(--danger)'}">${rateB}%</div>
            <div style="font-size:12px;color:var(--text-muted)">${runsB.length} runov · Build ${escHtml(runB.build_number)}</div>
        </div>
    </div>
    <div style="display:flex;gap:16px;padding:10px 16px;border-bottom:1px solid var(--border);flex-wrap:wrap;font-size:13px">
        <span style="color:var(--success)">✅ Opravené v B: <strong>${fixed}</strong></span>
        <span style="color:var(--danger)">❌ Nové pády v B: <strong>${broken}</strong></span>
        <span style="color:var(--warn)">🔁 Stále padá: <strong>${stillFail}</strong></span>
    </div>
    <table><thead><tr>
        <th>Zmena</th><th>Feature</th><th>Scenár</th><th>Tagy</th><th>Branch A</th><th>Branch B</th>
    </tr></thead><tbody>`;

    rows.forEach(r => {
        const colors = {fixed:'var(--success)',broken:'var(--danger)',fail:'var(--warn)',pass:'var(--text-muted)',accent:'var(--accent)',muted:'var(--text-muted)'};
        html += `<tr>
            <td style="color:${colors[r.cls]||'var(--text)'};font-weight:600;white-space:nowrap">${r.change}</td>
            <td class="muted" style="font-size:12px">${escHtml(r.feat)}</td>
            <td>${escHtml(r.scen)}</td>
            <td>${renderTags(r.tags)}</td>
            <td>${statusPill(r.stA)}</td>
            <td>${statusPill(r.stB)}</td>
        </tr>`;
    });
    html += '</tbody></table>';
    document.getElementById('branch-compare-body').innerHTML = html;
}

async function buildMap(features) {
    const map = new Map();
    await Promise.all(features.map(async f => {
        const scenarios = await fetchJson(`api/dev_data.php?action=scenarios&feature_id=${f.id}`);
        scenarios.forEach(s => map.set(f.name + '|||' + s.name, s));
    }));
    return map;
}

function statusPill(s) {
    if (!s || s === 'missing') return '<span class="muted">—</span>';
    return `<span class="badge badge-${s}">${s}</span>`;
}

function renderTags(tags) {
    if (!tags) return '<span class="muted">—</span>';
    return tags.split(',').map(t =>
        `<span style="display:inline-block;background:var(--accent-dim);color:var(--accent);border-radius:10px;padding:1px 7px;font-size:11px;margin:1px">${escHtml(t.trim())}</span>`
    ).join(' ');
}

function escHtml(str) {
    if (!str) return '';
    return String(str).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}
</script>
</body>
</html>
