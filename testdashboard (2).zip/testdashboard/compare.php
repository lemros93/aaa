<?php
require_once 'config/db.php';
$db         = getDb();
$pageTitle  = 'Porovnanie runov – Test Dashboard';
$activePage = 'compare';

// Posledných 30 runov pre výber
$runs = $db->query("SELECT id, project, run_at, build_number, branch,
                           passed_scenarios, failed_scenarios, total_scenarios
                    FROM runs ORDER BY run_at DESC LIMIT 50")->fetchAll();

include 'partials/header.php';
?>

<div class="filters" style="gap:16px">
    <span class="filter-label">Run A</span>
    <select id="run-a" class="filter-input" style="min-width:280px">
        <option value="">— vyber run —</option>
        <?php foreach ($runs as $r): ?>
        <option value="<?= $r['id'] ?>">
            <?= date('d.m.Y H:i', strtotime($r['run_at'])) ?>
            · <?= htmlspecialchars($r['project']) ?>
            · Build <?= htmlspecialchars($r['build_number']) ?>
            (✓<?= $r['passed_scenarios'] ?> ✗<?= $r['failed_scenarios'] ?>)
        </option>
        <?php endforeach; ?>
    </select>

    <span class="filter-label">vs Run B</span>
    <select id="run-b" class="filter-input" style="min-width:280px">
        <option value="">— vyber run —</option>
        <?php foreach ($runs as $r): ?>
        <option value="<?= $r['id'] ?>">
            <?= date('d.m.Y H:i', strtotime($r['run_at'])) ?>
            · <?= htmlspecialchars($r['project']) ?>
            · Build <?= htmlspecialchars($r['build_number']) ?>
            (✓<?= $r['passed_scenarios'] ?> ✗<?= $r['failed_scenarios'] ?>)
        </option>
        <?php endforeach; ?>
    </select>

    <button class="apply-btn" onclick="compare()">Porovnať</button>
</div>

<div class="main">

    <!-- Summary diff cards -->
    <div id="summary-cards" style="display:none" class="cards">
        <div class="card" id="card-fixed">
            <div class="card-label">✅ Opravené</div>
            <div class="card-value success" id="cnt-fixed">0</div>
            <div class="card-sub">v Run A padalo, v Run B prešlo</div>
        </div>
        <div class="card" id="card-broken">
            <div class="card-label">❌ Nové pády</div>
            <div class="card-value danger" id="cnt-broken">0</div>
            <div class="card-sub">v Run A prešlo, v Run B padá</div>
        </div>
        <div class="card">
            <div class="card-label">🔁 Stále padá</div>
            <div class="card-value" id="cnt-still-fail">0</div>
            <div class="card-sub">padá v oboch runoch</div>
        </div>
        <div class="card">
            <div class="card-label">✓ Stále prechádza</div>
            <div class="card-value" id="cnt-still-pass">0</div>
            <div class="card-sub">prechádza v oboch runoch</div>
        </div>
    </div>

    <!-- Results table -->
    <div class="table-wrap" id="compare-table" style="display:none">
        <div class="table-header">
            <span class="table-title">Porovnanie scenárov</span>
            <span class="table-count" id="compare-count"></span>
            <div class="flex ml-auto" style="gap:6px">
                <button class="quick-btn active" data-filter="all"    onclick="filterChange(this)">Všetky</button>
                <button class="quick-btn"        data-filter="broken" onclick="filterChange(this)">❌ Nové pády</button>
                <button class="quick-btn"        data-filter="fixed"  onclick="filterChange(this)">✅ Opravené</button>
                <button class="quick-btn"        data-filter="fail"   onclick="filterChange(this)">🔁 Stále padá</button>
            </div>
        </div>
        <table>
            <thead>
                <tr>
                    <th>Zmena</th>
                    <th>Feature</th>
                    <th>Scenár</th>
                    <th>Tagy</th>
                    <th>Run A</th>
                    <th>Run B</th>
                </tr>
            </thead>
            <tbody id="compare-tbody"></tbody>
        </table>
    </div>

    <div id="compare-empty" class="empty" style="display:none">
        <div class="empty-icon">🔍</div>
        Vyber dva runy a klikni Porovnať
    </div>

</div>

<script>
let allRows = [];

async function compare() {
    const a = document.getElementById('run-a').value;
    const b = document.getElementById('run-b').value;
    if (!a || !b) { alert('Vyber oba runy'); return; }
    if (a === b)  { alert('Vyber dva rôzne runy'); return; }

    document.getElementById('compare-table').style.display = 'none';
    document.getElementById('summary-cards').style.display = 'none';

    const [featA, featB] = await Promise.all([
        fetchJson(`api/dev_data.php?action=features&run_id=${a}`),
        fetchJson(`api/dev_data.php?action=features&run_id=${b}`)
    ]);

    // Build scenario maps: key = "featureName|||scenarioName"
    const mapA = await buildScenarioMap(featA);
    const mapB = await buildScenarioMap(featB);

    // Compare
    const allKeys = new Set([...mapA.keys(), ...mapB.keys()]);
    allRows = [];

    let fixed = 0, broken = 0, stillFail = 0, stillPass = 0;

    for (const key of allKeys) {
        const sa = mapA.get(key);
        const sb = mapB.get(key);

        const statusA = sa ? sa.status : 'missing';
        const statusB = sb ? sb.status : 'missing';

        let change, changeClass;
        if (statusA === 'failed' && statusB === 'passed') {
            change = '✅ Opravené'; changeClass = 'fixed'; fixed++;
        } else if (statusA === 'passed' && statusB === 'failed') {
            change = '❌ Nový pád'; changeClass = 'broken'; broken++;
        } else if (statusA === 'failed' && statusB === 'failed') {
            change = '🔁 Stále padá'; changeClass = 'fail'; stillFail++;
        } else if (statusA === 'missing') {
            change = '🆕 Nový'; changeClass = 'new';
        } else if (statusB === 'missing') {
            change = '🗑 Chýba'; changeClass = 'missing';
        } else {
            change = '✓ OK'; changeClass = 'pass'; stillPass++;
        }

        const s = sb || sa;
        allRows.push({ key, change, changeClass, statusA, statusB, s });
    }

    // Update cards
    document.getElementById('cnt-fixed').textContent     = fixed;
    document.getElementById('cnt-broken').textContent    = broken;
    document.getElementById('cnt-still-fail').textContent = stillFail;
    document.getElementById('cnt-still-pass').textContent = stillPass;
    document.getElementById('summary-cards').style.display = 'grid';

    renderRows('all');
    document.getElementById('compare-table').style.display = 'block';
}

async function buildScenarioMap(features) {
    const map = new Map();
    await Promise.all(features.map(async f => {
        const scenarios = await fetchJson(`api/dev_data.php?action=scenarios&feature_id=${f.id}`);
        scenarios.forEach(s => {
            const key = f.name + '|||' + s.name;
            map.set(key, { ...s, featureName: f.name, featureTags: f.tags });
        });
    }));
    return map;
}

function renderRows(filter) {
    const tbody = document.getElementById('compare-tbody');
    const rows  = filter === 'all' ? allRows : allRows.filter(r => r.changeClass === filter);
    document.getElementById('compare-count').textContent = rows.length + ' scenárov';

    tbody.innerHTML = rows.map(r => {
        const [featName, scenName] = r.key.split('|||');
        const changeColor = {
            fixed:   'var(--success)',
            broken:  'var(--danger)',
            fail:    'var(--warn)',
            pass:    'var(--text-muted)',
            new:     'var(--accent)',
            missing: 'var(--text-muted)'
        }[r.changeClass] || 'var(--text)';

        return `<tr>
            <td style="color:${changeColor}; font-weight:600; white-space:nowrap">${r.change}</td>
            <td class="muted" style="font-size:12px">${escHtml(featName)}</td>
            <td>${escHtml(scenName)}</td>
            <td>${renderTags(r.s?.tags)}</td>
            <td>${statusPill(r.statusA)}</td>
            <td>${statusPill(r.statusB)}</td>
        </tr>`;
    }).join('');
}

function filterChange(btn) {
    document.querySelectorAll('.quick-btn[data-filter]').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    renderRows(btn.dataset.filter);
}

function statusPill(status) {
    if (!status || status === 'missing') return '<span class="muted">—</span>';
    return `<span class="badge badge-${status}">${status}</span>`;
}

function renderTags(tags) {
    if (!tags) return '<span class="muted">—</span>';
    return tags.split(',').map(t =>
        `<span style="display:inline-block;background:var(--accent-dim);color:var(--accent);border-radius:10px;padding:1px 7px;font-size:11px;margin:1px">${escHtml(t.trim())}</span>`
    ).join(' ');
}

function escHtml(str) {
    if (!str) return '';
    return String(str).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}
</script>
</body>
</html>
