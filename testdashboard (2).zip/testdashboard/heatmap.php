<?php
require_once 'config/db.php';
$db         = getDb();
$pageTitle  = 'Heatmapa – Test Dashboard';
$activePage = 'heatmap';

$project  = $_GET['project']  ?? 'all';
$parallel = $_GET['parallel'] ?? 'all';
$months   = (int)($_GET['months'] ?? 3);
$from     = date('Y-m-d', strtotime("-{$months} months"));
$to       = date('Y-m-d');
$toEnd    = $to . ' 23:59:59';

$filters = ['r.run_at BETWEEN :from AND :to'];
$params  = [':from' => $from, ':to' => $toEnd];
if ($project  !== 'all') { $filters[] = 'project = :project';       $params[':project']  = $project; }
if ($parallel !== 'all') { $filters[] = 'parallel_mode = :parallel'; $params[':parallel'] = $parallel; }

$where = 'WHERE ' . implode(' AND ', $filters);

$sql = "SELECT
    DATE(run_at) AS day,
    COUNT(*) AS run_count,
    ROUND(SUM(passed_scenarios)/NULLIF(SUM(total_scenarios),0)*100,1) AS success_rate,
    SUM(failed_scenarios) AS failed_scenarios
FROM runs $where
GROUP BY DATE(run_at)";

$stmt = $db->prepare($sql);
foreach ($params as $k => $v) $stmt->bindValue($k, $v);
$stmt->execute();
$byDay = [];
foreach ($stmt->fetchAll() as $r) $byDay[$r['day']] = $r;

$projects = $db->query("SELECT DISTINCT project FROM runs ORDER BY project")->fetchAll(PDO::FETCH_COLUMN);

// Build calendar data as JSON for JS rendering
$calData = [];
$cur = new DateTime($from);
$end = new DateTime($to);
while ($cur <= $end) {
    $d = $cur->format('Y-m-d');
    $calData[$d] = $byDay[$d] ?? null;
    $cur->modify('+1 day');
}

include 'partials/header.php';
include 'partials/filters.php';
?>

<div class="main">

<!-- Month filter -->
<div style="display:flex;align-items:center;gap:8px;margin-bottom:12px">
    <span class="filter-label">Zobraziť</span>
    <?php foreach ([1,2,3,6] as $m): ?>
    <button class="quick-btn <?= $months===$m?'active':'' ?>" onclick="setMonths(<?= $m ?>)"><?= $m ?> mes.</button>
    <?php endforeach; ?>
</div>

<!-- Legend -->
<div style="display:flex;align-items:center;gap:12px;margin-bottom:16px;font-size:12px">
    <span class="muted">Úspešnosť:</span>
    <?php foreach ([
        ['#1e2535','Žiadny run'],
        ['#3b1212','< 50%'],
        ['#3b2a05','50–79%'],
        ['#0d3325','80–99%'],
        ['#34d399','100%'],
    ] as [$bg, $label]): ?>
    <span style="display:flex;gap:4px;align-items:center">
        <span style="width:14px;height:14px;background:<?= $bg ?>;border-radius:2px;display:inline-block;border:1px solid rgba(255,255,255,0.1)"></span>
        <span class="muted"><?= $label ?></span>
    </span>
    <?php endforeach; ?>
</div>

<!-- Calendar rendered by JS -->
<div class="table-wrap" style="padding:20px;overflow-x:auto">
    <div id="heatmap-container"></div>
</div>

<!-- Day detail -->
<div class="table-wrap" id="day-detail" style="display:none;margin-top:16px">
    <div class="table-header">
        <span class="table-title" id="day-title">Detail dňa</span>
        <button class="expand-btn ml-auto" onclick="document.getElementById('day-detail').style.display='none'">✕</button>
    </div>
    <div id="day-body"></div>
</div>

</div>

<script>
const calData = <?= json_encode($byDay) ?>;
const fromDate = '<?= $from ?>';
const toDate   = '<?= $to ?>';
const project  = '<?= urlencode($project) ?>';

function setMonths(m) {
    const url = new URL(location.href);
    url.searchParams.set('months', m);
    location.href = url.toString();
}

function buildHeatmap() {
    const container = document.getElementById('heatmap-container');
    const start = new Date(fromDate);
    const end   = new Date(toDate);

    // Snap start to Monday
    const startMon = new Date(start);
    const dow = startMon.getDay();
    const diff = (dow === 0 ? -6 : 1 - dow);
    startMon.setDate(startMon.getDate() + diff);

    // Build weeks array
    const weeks = [];
    const cur = new Date(startMon);
    while (cur <= end) {
        const week = [];
        for (let i = 0; i < 7; i++) {
            week.push(new Date(cur));
            cur.setDate(cur.getDate() + 1);
        }
        weeks.push(week);
    }

    // Month headers
    const DAY_SIZE = 16;
    const DAY_GAP  = 3;
    const CELL     = DAY_SIZE + DAY_GAP;

    let monthHtml = '<div style="display:flex;margin-left:32px;margin-bottom:2px;height:16px">';
    let lastMonth = '';
    let monthStart = 0;
    weeks.forEach((week, wi) => {
        const month = week[0].toLocaleString('sk-SK', {month:'short', year:'numeric'});
        if (month !== lastMonth) {
            if (lastMonth !== '') {
                monthHtml += `<div style="min-width:${(wi - monthStart) * CELL}px;font-size:11px;color:var(--text-muted);font-weight:600">${lastMonth}</div>`;
            }
            lastMonth  = month;
            monthStart = wi;
        }
    });
    // Last month label
    monthHtml += `<div style="flex:1;font-size:11px;color:var(--text-muted);font-weight:600">${lastMonth}</div>`;
    monthHtml += '</div>';

    // Day labels column
    const dayNames = ['Po','Ut','St','Št','Pi','So','Ne'];
    let dayLabels = '<div style="display:flex;flex-direction:column;gap:' + DAY_GAP + 'px;margin-right:6px">';
    dayNames.forEach(d => {
        dayLabels += `<div style="font-size:10px;color:var(--text-muted);height:${DAY_SIZE}px;line-height:${DAY_SIZE}px;width:24px;text-align:right">${d}</div>`;
    });
    dayLabels += '</div>';

    // Weeks grid
    let weeksHtml = '';
    weeks.forEach(week => {
        weeksHtml += `<div style="display:flex;flex-direction:column;gap:${DAY_GAP}px">`;
        week.forEach(day => {
            const ds = day.toISOString().split('T')[0];
            const inRange = ds >= fromDate && ds <= toDate;
            const d = calData[ds];

            let bg, title, clickable;
            if (!inRange) {
                bg = 'transparent'; title = ''; clickable = false;
            } else if (!d) {
                bg = 'var(--bg3)'; title = ds + ': žiadny run'; clickable = false;
            } else {
                const rate = d.success_rate;
                if (rate == 100)    bg = '#34d399';
                else if (rate >= 80) bg = '#0d3325';
                else if (rate >= 50) bg = '#3b2a05';
                else                 bg = '#3b1212';
                title = `${ds}: ${rate}% (${d.run_count} run${d.run_count>1?'y':''}, ✗${d.failed_scenarios} scenárov)`;
                clickable = true;
            }

            weeksHtml += `<div
                style="width:${DAY_SIZE}px;height:${DAY_SIZE}px;background:${bg};border-radius:2px;cursor:${clickable?'pointer':'default'}"
                title="${escHtml(title)}"
                ${clickable ? `onclick="showDay('${ds}')"` : ''}
            ></div>`;
        });
        weeksHtml += '</div>';
    });

    container.innerHTML = monthHtml +
        `<div style="display:flex;gap:${DAY_GAP}px">` + dayLabels + weeksHtml + '</div>';
}

async function showDay(date) {
    document.getElementById('day-detail').style.display = 'block';
    document.getElementById('day-title').textContent = 'Runy dňa ' + date;
    document.getElementById('day-body').innerHTML =
        '<div class="empty"><div class="spinner" style="margin:0 auto 8px;display:block;width:20px;height:20px"></div>Načítavam...</div>';

    const data = await fetchJson(`api/dev_data.php?action=runs&from=${date}&to=${date}&project=${project}`);
    if (!data.length) {
        document.getElementById('day-body').innerHTML = '<div class="empty">Žiadne runy</div>';
        return;
    }
    let html = '<table><thead><tr><th>Čas</th><th>Branch</th><th>Commit</th><th>Build</th><th>Beh</th><th>Scenáre ✓/✗</th><th>Úspešnosť</th><th>Čas buildu</th></tr></thead><tbody>';
    data.forEach(r => {
        const rate   = r.success_rate || 0;
        const commit = r.commit_hash ? r.commit_hash.substring(0,8) : '—';
        const isP    = r.parallel_mode === 'parallel';
        html += `<tr>
            <td class="nowrap">${formatDate(r.run_at)}</td>
            <td class="mono">${escHtml(r.branch||'—')}</td>
            <td class="mono">${escHtml(commit)}</td>
            <td class="mono">${escHtml(r.build_number)}</td>
            <td>${isP ? `<span style="color:var(--accent)">⚡ ×${r.thread_count}</span>` : '<span class="muted">serial</span>'}</td>
            <td>
                <span style="color:var(--success)">✓${r.passed_scenarios}</span>
                <span style="color:var(--danger)"> ✗${r.failed_scenarios}</span>
                / ${r.total_scenarios}
            </td>
            <td><span class="pct ${rate>=80?'good':'bad'}">${rate}%</span></td>
            <td class="nowrap">${formatDuration(r.wall_clock_ms)}</td>
        </tr>`;
    });
    html += '</tbody></table>';
    document.getElementById('day-body').innerHTML = html;
    document.getElementById('day-detail').scrollIntoView({behavior:'smooth',block:'nearest'});
}

function escHtml(str) {
    if (!str) return '';
    return String(str).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

buildHeatmap();
</script>
</body>
</html>
