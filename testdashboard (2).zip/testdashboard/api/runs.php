<?php
header('Content-Type: application/json');
require_once '../config/db.php';

$db      = getDb();
$from    = $_GET['from']    ?? date('Y-m-d', strtotime('-14 days'));
$to      = $_GET['to']      ?? date('Y-m-d');
$project = $_GET['project'] ?? 'all';
$toEnd   = $to . ' 23:59:59';

$projectFilter = $project !== 'all' ? 'AND r.project = :project' : '';

$sql = "SELECT
    r.id, r.project, r.project_type, r.run_at, r.duration_ms,
    r.triggered_by, r.trigger_type, r.branch, r.environment, r.build_number,
    r.total_features,  r.passed_features,  r.failed_features,
    r.total_scenarios, r.passed_scenarios, r.failed_scenarios,
    r.total_steps,     r.passed_steps,     r.failed_steps,     r.skipped_steps,
    ROUND(r.passed_scenarios / NULLIF(r.total_scenarios,0) * 100, 1) AS success_rate,
    GROUP_CONCAT(DISTINCT CONCAT(rm.meta_key,'=',rm.meta_value) SEPARATOR '|') AS meta
FROM runs r
LEFT JOIN run_metadata rm ON rm.run_id = r.id
WHERE r.run_at BETWEEN :from AND :to
$projectFilter
GROUP BY r.id
ORDER BY r.run_at DESC";

$stmt = $db->prepare($sql);
$stmt->bindValue(':from', $from);
$stmt->bindValue(':to',   $toEnd);
if ($project !== 'all') $stmt->bindValue(':project', $project);
$stmt->execute();
$runs = $stmt->fetchAll();

// Parse meta string into key-value pairs
foreach ($runs as &$run) {
    $meta = [];
    if ($run['meta']) {
        foreach (explode('|', $run['meta']) as $pair) {
            [$k, $v] = explode('=', $pair, 2);
            $meta[$k] = $v;
        }
    }
    $run['meta'] = $meta;
    $run['duration_formatted'] = gmdate('H:i:s', ($run['duration_ms'] ?? 0) / 1000);
}

$projects = $db->query("SELECT DISTINCT project FROM runs ORDER BY project")->fetchAll(PDO::FETCH_COLUMN);

echo json_encode(['runs' => $runs, 'projects' => $projects]);
