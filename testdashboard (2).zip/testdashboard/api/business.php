<?php
header('Content-Type: application/json');
require_once '../config/db.php';

$db       = getDb();
$from     = $_GET['from']    ?? date('Y-m-d', strtotime('-14 days'));
$to       = $_GET['to']      ?? date('Y-m-d');
$project  = $_GET['project'] ?? 'all';

$toEnd = $to . ' 23:59:59';

$projectFilter = $project !== 'all' ? 'AND r.project = :project' : '';

// Runs summary
$sql = "SELECT
    r.id,
    r.project,
    r.run_at,
    r.build_number,
    r.total_features,  r.passed_features,  r.failed_features,
    r.total_scenarios, r.passed_scenarios, r.failed_scenarios,
    r.total_steps,     r.passed_steps,     r.failed_steps,     r.skipped_steps,
    ROUND(r.passed_scenarios / NULLIF(r.total_scenarios,0) * 100, 1) AS success_rate
FROM runs r
WHERE r.run_at BETWEEN :from AND :to
$projectFilter
ORDER BY r.run_at DESC";

$stmt = $db->prepare($sql);
$stmt->bindValue(':from', $from);
$stmt->bindValue(':to',   $toEnd);
if ($project !== 'all') $stmt->bindValue(':project', $project);
$stmt->execute();
$runs = $stmt->fetchAll();

// Projects list for filter
$projects = $db->query("SELECT DISTINCT project FROM runs ORDER BY project")->fetchAll(PDO::FETCH_COLUMN);

echo json_encode(['runs' => $runs, 'projects' => $projects]);
