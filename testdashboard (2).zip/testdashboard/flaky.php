<?php
require_once 'config/db.php';
$db         = getDb();
$pageTitle  = 'Rizikové testy – Test Dashboard';
$activePage = 'flaky';

$from    = $_GET['from']    ?? date('Y-m-d', strtotime('-30 days'));
$to      = $_GET['to']      ?? date('Y-m-d');
$project = $_GET['project'] ?? 'all';
$toEnd   = $to . ' 23:59:59';
$pf      = $project !== 'all' ? 'AND r.project = :project' : '';

// Top failing scenarios
$sql = "SELECT
    f.name                                              AS feature_name,
    s.name                                              AS scenario_name,
    s.tags,
    COUNT(*)                                            AS total_runs,
    SUM(CASE WHEN s.status = 'failed'  THEN 1 ELSE 0 END) AS fail_count,
    SUM(CASE WHEN s.status = 'passed'  THEN 1 ELSE 0 END) AS pass_count,
    ROUND(SUM(CASE WHEN s.status='failed' THEN 1 ELSE 0 END) / COUNT(*) * 100, 1) AS fail_rate,
    MAX(r.run_at)                                       AS last_run,
    MAX(CASE WHEN s.status='failed' THEN r.run_at END)  AS last_fail
FROM scenarios s
JOIN features f  ON f.id = s.feature_id
JOIN runs r      ON r.id = f.run_id
WHERE r.run_at BETWEEN :from AND :to $pf
GROUP BY f.name, s.name, s.tags
HAVING total_runs > 1
ORDER BY fail_count DESC, fail_rate DESC
LIMIT 100";

$stmt = $db->prepare($sql);
$stmt->bindValue(':from', $from);
$stmt->bindValue(':to',   $toEnd);
if ($project !== 'all') $stmt->bindValue(':project', $project);
$stmt->execute();
$scenarios = $stmt->fetchAll();

// Top failing features
$sql2 = "SELECT
    f.name                                              AS feature_name,
    f.tags,
    COUNT(DISTINCT r.id)                                AS total_runs,
    SUM(CASE WHEN f.status = 'failed'  THEN 1 ELSE 0 END) AS fail_count,
    ROUND(SUM(CASE WHEN f.status='failed' THEN 1 ELSE 0 END) / COUNT(DISTINCT r.id) * 100, 1) AS fail_rate
FROM features f
JOIN runs r ON r.id = f.run_id
WHERE r.run_at BETWEEN :from AND :to $pf
GROUP BY f.name, f.tags
HAVING total_runs > 1
ORDER BY fail_count DESC
LIMIT 20";

$stmt2 = $db->prepare($sql2);
$stmt2->bindValue(':from', $from);
$stmt2->bindValue(':to',   $toEnd);
if ($project !== 'all') $stmt2->bindValue(':project', $project);
$stmt2->execute();
$features = $stmt2->fetchAll();

include 'partials/header.php';
include 'partials/filters.php';
?>

<div class="main">

<!-- Top failing features -->
<div class="table-wrap" style="margin-bottom:20px">
    <div class="table-header">
        <span class="table-title">🔥 Najrizikivejšie features</span>
        <span class="table-count">Top <?= count($features) ?></span>
    </div>
    <?php if (empty($features)): ?>
        <div class="empty"><div class="empty-icon">✅</div>Žiadne opakujúce sa zlyhania</div>
    <?php else: ?>
    <table>
        <thead>
            <tr>
                <th>#</th>
                <th>Feature</th>
                <th>Tagy</th>
                <th>Runy</th>
                <th>Padlo</th>
                <th>Miera zlyhania</th>
                <th>Riziko</th>
            </tr>
        </thead>
        <tbody>
        <?php foreach ($features as $i => $f): ?>
            <tr>
                <td class="muted"><?= $i+1 ?></td>
                <td><?= htmlspecialchars($f['feature_name']) ?></td>
                <td><?php
                    if ($f['tags']) {
                        foreach (explode(',', $f['tags']) as $tag) {
                            echo '<span style="display:inline-block;background:var(--accent-dim);color:var(--accent);border-radius:10px;padding:1px 7px;font-size:11px;margin:1px">' . htmlspecialchars(trim($tag)) . '</span>';
                        }
                    } else echo '<span class="muted">—</span>';
                ?></td>
                <td><?= $f['total_runs'] ?></td>
                <td style="color:var(--danger); font-weight:600"><?= $f['fail_count'] ?>×</td>
                <td><?php
                    $rate = $f['fail_rate'];
                    $color = $rate >= 75 ? 'var(--danger)' : ($rate >= 40 ? 'var(--warn)' : 'var(--success)');
                    echo "<span style='color:$color; font-weight:600'>$rate%</span>";
                ?></td>
                <td style="min-width:100px"><?php
                    $rate = $f['fail_rate'];
                    echo "<div class='progress'><div class='progress-fail' style='width:{$rate}%'></div></div>";
                ?></td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    <?php endif; ?>
</div>

<!-- Top failing scenarios -->
<div class="table-wrap">
    <div class="table-header">
        <span class="table-title">🔥 Najrizikivejšie scenáre</span>
        <span class="table-count" id="scen-count">Top <?= count($scenarios) ?></span>
        <div class="flex ml-auto" style="gap:8px">
            <input type="text" id="scen-search" class="filter-input" placeholder="🔍 Filter podľa názvu / tagu / regex..."
                   style="width:280px" oninput="filterScenarios()">
        </div>
    </div>
    <?php if (empty($scenarios)): ?>
        <div class="empty"><div class="empty-icon">✅</div>Žiadne opakujúce sa zlyhania</div>
    <?php else: ?>
    <table>
        <thead>
            <tr>
                <th>#</th>
                <th>Feature</th>
                <th>Scenár</th>
                <th>Tagy</th>
                <th>Runy</th>
                <th>Padlo</th>
                <th>Prešlo</th>
                <th>Miera zlyhania</th>
                <th>Posledný pád</th>
                <th>Riziko</th>
            </tr>
        </thead>
        <tbody id="scen-tbody">
        <?php foreach ($scenarios as $i => $s):
            $rate  = $s['fail_rate'];
            $color = $rate >= 75 ? 'var(--danger)' : ($rate >= 40 ? 'var(--warn)' : 'var(--text-muted)');
            $lastFail = $s['last_fail'] ? date('d.m.Y H:i', strtotime($s['last_fail'])) : '—';
        ?>
            <tr data-name="<?= htmlspecialchars(strtolower($s['scenario_name'] . ' ' . $s['feature_name'] . ' ' . $s['tags'])) ?>">
                <td class="muted"><?= $i+1 ?></td>
                <td class="muted" style="font-size:12px; max-width:180px"><?= htmlspecialchars($s['feature_name']) ?></td>
                <td style="max-width:300px"><?= htmlspecialchars($s['scenario_name']) ?></td>
                <td><?php
                    if ($s['tags']) {
                        foreach (explode(',', $s['tags']) as $tag) {
                            echo '<span style="display:inline-block;background:var(--accent-dim);color:var(--accent);border-radius:10px;padding:1px 7px;font-size:11px;margin:1px">' . htmlspecialchars(trim($tag)) . '</span>';
                        }
                    } else echo '<span class="muted">—</span>';
                ?></td>
                <td><?= $s['total_runs'] ?></td>
                <td style="color:var(--danger); font-weight:600"><?= $s['fail_count'] ?>×</td>
                <td style="color:var(--success)"><?= $s['pass_count'] ?>×</td>
                <td><span style="color:<?= $color ?>; font-weight:600"><?= $rate ?>%</span></td>
                <td class="nowrap muted" style="font-size:12px"><?= $lastFail ?></td>
                <td style="min-width:80px">
                    <div class="progress">
                        <div class="progress-fail" style="width:<?= $rate ?>%"></div>
                        <div class="progress-pass" style="width:<?= 100-$rate ?>%"></div>
                    </div>
                </td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    <?php endif; ?>
</div>

</div>

<script>
function filterScenarios() {
    const raw   = document.getElementById('scen-search').value.trim();
    const rows  = document.querySelectorAll('#scen-tbody tr');
    let visible = 0;

    let regex;
    try {
        regex = raw ? new RegExp(raw, 'i') : null;
    } catch(e) {
        // Neplatný regex — použi ako plain text
        regex = raw ? new RegExp(raw.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'i') : null;
    }

    rows.forEach(row => {
        const text = row.dataset.name || '';
        const show = !regex || regex.test(text);
        row.style.display = show ? '' : 'none';
        if (show) visible++;
    });

    document.getElementById('scen-count').textContent = visible + ' scenárov';
}
</script>
</body>
</html>
