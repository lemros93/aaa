<?php
$projects = $db->query("SELECT DISTINCT project FROM runs ORDER BY project")->fetchAll(PDO::FETCH_COLUMN);
$curFrom     = $_GET['from']     ?? date('Y-m-d', strtotime('-14 days'));
$curTo       = $_GET['to']       ?? date('Y-m-d');
$curProj     = $_GET['project']  ?? 'all';
$curParallel = $_GET['parallel'] ?? 'all';
?>
<div class="filters">
    <span class="filter-label">Obdobie</span>
    <button class="quick-btn" data-days="1"  onclick="setQuick(1)">24h</button>
    <button class="quick-btn" data-days="7"  onclick="setQuick(7)">7 dní</button>
    <button class="quick-btn" data-days="14" onclick="setQuick(14)">14 dní</button>
    <button class="quick-btn" data-days="30" onclick="setQuick(30)">30 dní</button>

    <div class="filter-sep"></div>

    <input type="date" id="date-from" class="filter-input" value="<?= $curFrom ?>">
    <span class="muted">—</span>
    <input type="date" id="date-to"   class="filter-input" value="<?= $curTo ?>">

    <div class="filter-sep"></div>

    <select id="project-select" class="filter-input">
        <option value="all" <?= $curProj==='all'?'selected':'' ?>>Všetky projekty</option>
        <?php foreach ($projects as $p): ?>
        <option value="<?= htmlspecialchars($p) ?>" <?= $curProj===$p?'selected':'' ?>>
            <?= htmlspecialchars($p) ?>
        </option>
        <?php endforeach; ?>
    </select>

    <select id="parallel-select" class="filter-input">
        <option value="all"      <?= $curParallel==='all'     ?'selected':'' ?>>Serial + Parallel</option>
        <option value="serial"   <?= $curParallel==='serial'  ?'selected':'' ?>>Serial</option>
        <option value="parallel" <?= $curParallel==='parallel'?'selected':'' ?>>⚡ Parallel</option>
    </select>

    <button class="apply-btn" onclick="applyFilters()">Použiť</button>
</div>
<script>
if (document.getElementById('date-from')) initFilters();

// Override applyFilters to include parallel
function applyFilters() {
    const from     = document.getElementById('date-from')?.value;
    const to       = document.getElementById('date-to')?.value;
    const proj     = document.getElementById('project-select')?.value  || 'all';
    const parallel = document.getElementById('parallel-select')?.value || 'all';
    const url = new URL(location.href);
    if (from)    url.searchParams.set('from',     from);
    if (to)      url.searchParams.set('to',       to);
    url.searchParams.set('project',  proj);
    url.searchParams.set('parallel', parallel);
    location.href = url.toString();
}
</script>
