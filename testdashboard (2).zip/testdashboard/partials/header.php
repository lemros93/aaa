<!DOCTYPE html>
<html lang="sk" data-theme="dark">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= htmlspecialchars($pageTitle ?? 'Test Dashboard') ?></title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="/automation/assets/css/theme.css">
</head>
<body>

<nav class="topbar">
    <span class="topbar-brand">🧪 Test Dashboard</span>
    <div class="topbar-nav">
        <a href="/automation/index.php"      class="<?= $activePage==='business'   ? 'active' : '' ?>">📊 Business</a>
        <a href="/automation/runs.php"       class="<?= $activePage==='runs'       ? 'active' : '' ?>">🏃 Runs</a>
        <a href="/automation/developer.php"  class="<?= $activePage==='developer'  ? 'active' : '' ?>">🛠 Developer</a>
        <a href="/automation/compare.php"    class="<?= $activePage==='compare'    ? 'active' : '' ?>">⚖️ Porovnanie</a>
        <a href="/automation/flaky.php"      class="<?= $activePage==='flaky'      ? 'active' : '' ?>">🔥 Rizikové</a>
    </div>
    <div class="topbar-right">
        <button class="theme-btn" onclick="toggleTheme()">☀️ Light</button>
    </div>
</nav>

<!-- Image overlay -->
<div class="overlay" id="overlay" onclick="if(event.target===this)closeOverlay()">
    <span class="overlay-close" onclick="closeOverlay()">✕</span>
    <img class="overlay-img" id="overlay-img" src="" alt="">
</div>

<script src="/automation/assets/js/app.js"></script>
