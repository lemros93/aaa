<?php
require_once 'config/db.php';
$db        = getDb();
$pageTitle = 'Business – Test Dashboard';
$activePage = 'business';

$from    = $_GET['from']    ?? date('Y-m-d', strtotime('-14 days'));
$to      = $_GET['to']      ?? date('Y-m-d');
$project = $_GET['project'] ?? 'all';
$toEnd   = $to . ' 23:59:59';
$pf      = $project !== 'all' ? 'AND r.project = :project' : '';

// Aggregate totals for summary cards
$sql = "SELECT
    COUNT(*)                        AS total_runs,
    SUM(r.total_features)           AS total_features,
    SUM(r.passed_features)          AS passed_features,
    SUM(r.failed_features)          AS failed_features,
    SUM(r.total_scenarios)          AS total_scenarios,
    SUM(r.passed_scenarios)         AS passed_scenarios,
    SUM(r.failed_scenarios)         AS failed_scenarios,
    SUM(r.total_steps)              AS total_steps,
    SUM(r.passed_steps)             AS passed_steps,
    SUM(r.failed_steps)             AS failed_steps,
    ROUND(AVG(r.passed_scenarios/NULLIF(r.total_scenarios,0)*100),1) AS avg_success
FROM runs r
WHERE r.run_at BETWEEN :from AND :to $pf";
$stmt = $db->prepare($sql);
$stmt->bindValue(':from', $from); $stmt->bindValue(':to', $toEnd);
if ($project !== 'all') $stmt->bindValue(':project', $project);
$stmt->execute();
$totals = $stmt->fetch();

// Runs list
$sql2 = "SELECT r.id, r.project, r.run_at, r.build_number,
    r.total_features, r.passed_features, r.failed_features,
    r.total_scenarios, r.passed_scenarios, r.failed_scenarios,
    r.total_steps, r.passed_steps, r.failed_steps, r.skipped_steps,
    ROUND(r.passed_scenarios/NULLIF(r.total_scenarios,0)*100,1) AS success_rate
FROM runs r WHERE r.run_at BETWEEN :from AND :to $pf ORDER BY r.run_at DESC";
$stmt2 = $db->prepare($sql2);
$stmt2->bindValue(':from', $from); $stmt2->bindValue(':to', $toEnd);
if ($project !== 'all') $stmt2->bindValue(':project', $project);
$stmt2->execute();
$runs = $stmt2->fetchAll();

include 'partials/header.php';
include 'partials/filters.php';
?>

<div class="main">

<!-- Summary cards -->
<div class="cards">
    <div class="card">
        <div class="card-label">Runy</div>
        <div class="card-value accent"><?= $totals['total_runs'] ?? 0 ?></div>
        <div class="card-sub">v zvolenom období</div>
    </div>
    <div class="card">
        <div class="card-label">Features</div>
        <div class="card-value"><?= $totals['total_features'] ?? 0 ?></div>
        <div class="card-sub">
            <span style="color:var(--success)">✓ <?= $totals['passed_features'] ?? 0 ?></span>
            &nbsp;
            <span style="color:var(--danger)">✗ <?= $totals['failed_features'] ?? 0 ?></span>
        </div>
    </div>
    <div class="card">
        <div class="card-label">Scenáre</div>
        <div class="card-value"><?= $totals['total_scenarios'] ?? 0 ?></div>
        <div class="card-sub">
            <span style="color:var(--success)">✓ <?= $totals['passed_scenarios'] ?? 0 ?></span>
            &nbsp;
            <span style="color:var(--danger)">✗ <?= $totals['failed_scenarios'] ?? 0 ?></span>
        </div>
    </div>
    <div class="card">
        <div class="card-label">Stepy</div>
        <div class="card-value"><?= $totals['total_steps'] ?? 0 ?></div>
        <div class="card-sub">
            <span style="color:var(--success)">✓ <?= $totals['passed_steps'] ?? 0 ?></span>
            &nbsp;
            <span style="color:var(--danger)">✗ <?= $totals['failed_steps'] ?? 0 ?></span>
        </div>
    </div>
    <div class="card">
        <div class="card-label">Priemerná úspešnosť</div>
        <div class="card-value <?= ($totals['avg_success']??0) >= 80 ? 'success' : 'danger' ?>">
            <?= $totals['avg_success'] ?? 0 ?>%
        </div>
        <div class="card-sub">scenáre</div>
    </div>
</div>

<!-- Runs table -->
<div class="table-wrap">
    <div class="table-header">
        <span class="table-title">Prehľad runov</span>
        <span class="table-count"><?= count($runs) ?> runov</span>
    </div>
    <?php if (empty($runs)): ?>
        <div class="empty"><div class="empty-icon">📭</div>Žiadne dáta pre zvolené obdobie</div>
    <?php else: ?>
    <table>
        <thead>
            <tr>
                <th>Dátum</th>
                <th>Projekt</th>
                <th>Build</th>
                <th>Features</th>
                <th>Scenáre</th>
                <th>Stepy</th>
                <th>Úspešnosť</th>
                <th>Progress</th>
            </tr>
        </thead>
        <tbody>
        <?php foreach ($runs as $r): ?>
            <tr class="clickable-row" onclick="location.href='runs.php?from=<?= urlencode($from) ?>&to=<?= urlencode($to) ?>&project=<?= urlencode($project) ?>#run-<?= $r['id'] ?>'">
                <td class="nowrap"><?= date('d.m.Y H:i', strtotime($r['run_at'])) ?></td>
                <td><?= htmlspecialchars($r['project']) ?></td>
                <td class="mono"><?= htmlspecialchars($r['build_number']) ?></td>
                <td>
                    <span style="color:var(--success)"><?= $r['passed_features'] ?></span>/<?= $r['total_features'] ?>
                    <?php if ($r['failed_features'] > 0): ?>
                        <span style="color:var(--danger)"> (✗<?= $r['failed_features'] ?>)</span>
                    <?php endif; ?>
                </td>
                <td>
                    <span style="color:var(--success)"><?= $r['passed_scenarios'] ?></span>/<?= $r['total_scenarios'] ?>
                    <?php if ($r['failed_scenarios'] > 0): ?>
                        <span style="color:var(--danger)"> (✗<?= $r['failed_scenarios'] ?>)</span>
                    <?php endif; ?>
                </td>
                <td>
                    <span style="color:var(--success)"><?= $r['passed_steps'] ?></span>/<?= $r['total_steps'] ?>
                </td>
                <td>
                    <?php $sr = $r['success_rate'] ?? 0; ?>
                    <span class="pct <?= $sr >= 80 ? 'good' : 'bad' ?>"><?= $sr ?>%</span>
                </td>
                <td style="min-width:100px">
                    <?php
                        $t = max($r['total_scenarios'], 1);
                        $p = round($r['passed_scenarios']/$t*100);
                        $f = round($r['failed_scenarios']/$t*100);
                        $s = 100-$p-$f;
                    ?>
                    <div class="progress">
                        <div class="progress-pass" style="width:<?= $p ?>%"></div>
                        <div class="progress-fail" style="width:<?= $f ?>%"></div>
                        <div class="progress-skip" style="width:<?= $s ?>%"></div>
                    </div>
                </td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    <?php endif; ?>
</div>

</div><!-- .main -->
</body>
</html>
