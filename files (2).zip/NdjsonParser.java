package com.yourcompany.importer.parser;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.yourcompany.importer.model.*;
import com.yourcompany.importer.plugin.StepExtra;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.*;

public class NdjsonParser {

    private static final Logger log = LoggerFactory.getLogger(NdjsonParser.class);
    private final ObjectMapper mapper = new ObjectMapper();

    public TestRun parse(String filePath, Map<String, StepExtra> stepExtras) throws IOException {
        log.info("Parsing NDJSON file: {}", filePath);

        // Maps to correlate messages by their IDs
        Map<String, String> pickleIdToName         = new HashMap<>(); // pickleId -> scenario name
        Map<String, String> pickleIdToFeatureId    = new HashMap<>(); // pickleId -> featureId (uri)
        Map<String, String> testCaseIdToPickleId   = new HashMap<>(); // testCaseId -> pickleId
        Map<String, String> testCaseStartedToCase  = new HashMap<>(); // testCaseStartedId -> testCaseId
        Map<String, Feature> featureMap            = new LinkedHashMap<>(); // uri -> Feature
        Map<String, Scenario> scenarioMap          = new LinkedHashMap<>(); // testCaseStartedId -> Scenario
        Map<String, List<Step>> stepsMap           = new LinkedHashMap<>(); // testCaseStartedId -> steps

        long earliestTimestamp = Long.MAX_VALUE;

        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = reader.readLine()) != null) {
                line = line.trim();
                if (line.isEmpty()) continue;

                JsonNode root = mapper.readTree(line);

                // --- Source (feature file info) ---
                if (root.has("source")) {
                    JsonNode source = root.get("source");
                    String uri  = source.path("uri").asText();
                    Feature f   = new Feature();
                    f.filePath  = uri;
                    f.name      = extractFeatureName(uri);
                    featureMap.put(uri, f);
                }

                // --- GherkinDocument (contains feature name) ---
                if (root.has("gherkinDocument")) {
                    JsonNode doc = root.get("gherkinDocument");
                    String uri   = doc.path("uri").asText();
                    JsonNode feature = doc.path("feature");
                    if (!feature.isMissingNode()) {
                        Feature f = featureMap.computeIfAbsent(uri, u -> {
                            Feature nf = new Feature();
                            nf.filePath = u;
                            return nf;
                        });
                        f.name = feature.path("name").asText(f.name);
                    }
                }

                // --- Pickle (scenario definition) ---
                if (root.has("pickle")) {
                    JsonNode pickle = root.get("pickle");
                    String pickleId = pickle.path("id").asText();
                    String uri      = pickle.path("uri").asText();
                    String name     = pickle.path("name").asText();
                    pickleIdToName.put(pickleId, name);
                    pickleIdToFeatureId.put(pickleId, uri);
                }

                // --- TestCase ---
                if (root.has("testCase")) {
                    JsonNode tc       = root.get("testCase");
                    String tcId       = tc.path("id").asText();
                    String pickleId   = tc.path("pickleId").asText();
                    testCaseIdToPickleId.put(tcId, pickleId);
                }

                // --- TestCaseStarted ---
                if (root.has("testCaseStarted")) {
                    JsonNode tcs        = root.get("testCaseStarted");
                    String tcsId        = tcs.path("id").asText();
                    String tcId         = tcs.path("testCaseId").asText();
                    testCaseStartedToCase.put(tcsId, tcId);

                    long ts = getTimestampMs(tcs.path("timestamp"));
                    if (ts < earliestTimestamp) earliestTimestamp = ts;

                    // Pre-create scenario
                    String pickleId   = testCaseIdToPickleId.get(tcId);
                    String scenName   = pickleId != null ? pickleIdToName.getOrDefault(pickleId, "Unknown") : "Unknown";
                    Scenario scenario = new Scenario();
                    scenario.name     = scenName;
                    scenarioMap.put(tcsId, scenario);
                    stepsMap.put(tcsId, new ArrayList<>());
                }

                // --- TestStepFinished (individual step result) ---
                if (root.has("testStepFinished")) {
                    JsonNode tsf    = root.get("testStepFinished");
                    String tcsId    = tsf.path("testCaseStartedId").asText();
                    String testStepId = tsf.path("testStepId").asText();
                    JsonNode result = tsf.path("testStepResult");

                    String status   = mapStatus(result.path("status").asText());
                    long durationMs = getDurationMs(result.path("duration"));
                    String errorMsg = result.path("message").asText(null);

                    Step step       = new Step();
                    step.testStepId = testStepId;
                    step.status     = status;
                    step.durationMs = durationMs;

                    if (errorMsg != null && !errorMsg.isBlank()) {
                        String[] parts    = errorMsg.split("\n", 2);
                        step.errorMessage = parts[0].trim();
                        step.stackTrace   = parts.length > 1 ? parts[1].trim() : null;
                    }

                    List<Step> steps = stepsMap.computeIfAbsent(tcsId, k -> new ArrayList<>());
                    step.order = steps.size() + 1;
                    steps.add(step);
                }

                // --- TestCaseFinished ---
                if (root.has("testCaseFinished")) {
                    JsonNode tcf = root.get("testCaseFinished");
                    String tcsId = tcf.path("testCaseStartedId").asText();

                    Scenario scenario = scenarioMap.get(tcsId);
                    List<Step> steps  = stepsMap.getOrDefault(tcsId, Collections.emptyList());

                    if (scenario != null) {
                        // Enrich steps with translated text and screenshots via direct testStepId lookup
                        for (Step step : steps) {
                            StepExtra extra = stepExtras.get(step.testStepId);
                            if (extra != null) {
                                step.translatedText      = extra.translatedText;
                                step.screenshotUrl       = extra.screenshotUrl;
                                step.failedScreenshotUrl = extra.failedScreenshotUrl;
                            }
                        }

                        scenario.steps.addAll(steps);
                        scenario.computeStepAggregations();

                        // Attach to feature
                        String tcId     = testCaseStartedToCase.get(tcsId);
                        String pickleId = testCaseIdToPickleId.get(tcId);
                        String uri      = pickleIdToFeatureId.get(pickleId);
                        Feature feature = featureMap.get(uri);
                        if (feature != null) {
                            feature.scenarios.add(scenario);
                        }
                    }
                }
            }
        }

        // Build TestRun
        TestRun run = new TestRun();
        run.runAt   = earliestTimestamp == Long.MAX_VALUE
                ? LocalDateTime.now()
                : LocalDateTime.ofInstant(Instant.ofEpochMilli(earliestTimestamp), ZoneId.systemDefault());
        run.features.addAll(featureMap.values());
        run.computeAggregations();

        log.info("Parsed: {} features, {} scenarios, {} steps",
                run.totalFeatures, run.totalScenarios, run.totalSteps);
        log.info("Results: passed={}, failed={} (scenarios)",
                run.passedScenarios, run.failedScenarios);

        return run;
    }

    private String extractFeatureName(String uri) {
        if (uri == null) return "Unknown";
        String name = uri.contains("/") ? uri.substring(uri.lastIndexOf('/') + 1) : uri;
        return name.replace(".feature", "").replace("_", " ");
    }

    private String mapStatus(String raw) {
        return switch (raw.toUpperCase()) {
            case "PASSED"  -> "passed";
            case "FAILED"  -> "failed";
            case "SKIPPED", "PENDING", "UNDEFINED", "AMBIGUOUS" -> "skipped";
            default -> "skipped";
        };
    }

    private long getDurationMs(JsonNode duration) {
        if (duration.isMissingNode()) return 0;
        long seconds     = duration.path("seconds").asLong(0);
        long nanos       = duration.path("nanos").asLong(0);
        return seconds * 1000 + nanos / 1_000_000;
    }

    private long getTimestampMs(JsonNode timestamp) {
        if (timestamp.isMissingNode()) return System.currentTimeMillis();
        long seconds = timestamp.path("seconds").asLong(0);
        long nanos   = timestamp.path("nanos").asLong(0);
        return seconds * 1000 + nanos / 1_000_000;
    }
}
