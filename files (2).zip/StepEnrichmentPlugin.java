package com.yourcompany.importer.plugin;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.yourcompany.importer.context.StepContext;
import io.cucumber.plugin.EventListener;
import io.cucumber.plugin.event.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;

/**
 * Cucumber plugin that enriches step data with:
 * - translated step name (resolved property values)
 * - per-step screenshot URL (optional)
 * - failed step screenshot URL (optional)
 *
 * Output: steps-extra.ndjson (one JSON line per step)
 * Matched to cucumber.ndjson via testStepId — direct and parallel-safe.
 *
 * Register in @CucumberOptions:
 *   plugin = {"com.yourcompany.importer.plugin.StepEnrichmentPlugin:target/steps-extra.ndjson"}
 */
public class StepEnrichmentPlugin implements EventListener {

    private static final Logger log = LoggerFactory.getLogger(StepEnrichmentPlugin.class);

    private final ObjectMapper mapper = new ObjectMapper();
    private final Path outputPath;

    public StepEnrichmentPlugin(String outputPath) {
        this.outputPath = Paths.get(outputPath);
        initOutputFile();
    }

    @Override
    public void setEventPublisher(EventPublisher publisher) {
        publisher.registerHandlerFor(TestStepFinished.class, this::onTestStepFinished);
    }

    // -------------------------------------------------------------------------

    private void onTestStepFinished(TestStepFinished event) {
        // Skip Before/After hooks — we only want PickleSteps (actual Gherkin steps)
        if (!(event.getTestStep() instanceof PickleStepTestStep)) return;

        PickleStepTestStep step = (PickleStepTestStep) event.getTestStep();

        StepExtra extra = new StepExtra();
        extra.testStepId          = step.getId().toString();
        extra.translatedText      = StepContext.getCurrentStepName();
        extra.screenshotUrl       = nullIfBlank(StepContext.getScreenshotUrl());
        extra.failedScreenshotUrl = nullIfBlank(StepContext.getFailedScreenshotUrl());

        writeLine(extra);
    }

    // -------------------------------------------------------------------------

    private void initOutputFile() {
        try {
            Path parent = outputPath.getParent();
            if (parent != null) Files.createDirectories(parent);
            Files.write(outputPath, new byte[0],
                    StandardOpenOption.CREATE,
                    StandardOpenOption.TRUNCATE_EXISTING);
        } catch (IOException e) {
            log.error("StepEnrichmentPlugin: cannot create output file: {}", outputPath, e);
        }
    }

    private synchronized void writeLine(StepExtra extra) {
        // synchronized because multiple threads may write concurrently
        try (BufferedWriter writer = Files.newBufferedWriter(
                outputPath, StandardCharsets.UTF_8, StandardOpenOption.APPEND)) {
            writer.write(mapper.writeValueAsString(extra));
            writer.newLine();
        } catch (IOException e) {
            log.error("StepEnrichmentPlugin: failed to write step extra for testStepId={}",
                    extra.testStepId, e);
        }
    }

    private static String nullIfBlank(String s) {
        return (s == null || s.isBlank()) ? null : s;
    }
}
