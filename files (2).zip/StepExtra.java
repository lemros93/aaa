package com.yourcompany.importer.plugin;

/**
 * One record per step, written to steps-extra.ndjson after each step finishes.
 * Matched to NDJSON data in the importer directly via testStepId.
 */
public class StepExtra {
    public String testStepId;         // direct Cucumber step ID — unique per step per scenario
    public String translatedText;     // resolved property values, from StepContext
    public String screenshotUrl;      // per-step screenshot (optional, may be null)
    public String failedScreenshotUrl;// screenshot on failure (optional, may be null)
}
