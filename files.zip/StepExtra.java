package com.yourcompany.importer.plugin;

/**
 * One record per step, written to steps-extra.ndjson after each step finishes.
 * Matched to NDJSON data in the importer via testCaseStartedId + stepOrder.
 */
public class StepExtra {
    public String testCaseStartedId;
    public int    stepOrder;          // 1-based, matches insertion order in NdjsonParser
    public String translatedText;     // resolved property values, from StepContext
    public String screenshotUrl;      // per-step screenshot (optional, may be null)
    public String failedScreenshotUrl;// screenshot on failure (optional, may be null)
}
