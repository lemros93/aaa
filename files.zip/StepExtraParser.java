package com.yourcompany.importer.parser;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.yourcompany.importer.plugin.StepExtra;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;

/**
 * Reads steps-extra.ndjson and builds a lookup map:
 * testCaseStartedId + stepOrder -> StepExtra
 *
 * Used by NdjsonParser to enrich Step objects after parsing cucumber.ndjson.
 */
public class StepExtraParser {

    private static final Logger log = LoggerFactory.getLogger(StepExtraParser.class);
    private final ObjectMapper mapper = new ObjectMapper();

    /**
     * Key: "testCaseStartedId:stepOrder"  e.g. "abc-123:3"
     * Value: StepExtra
     */
    public Map<String, StepExtra> parse(String filePath) throws IOException {
        Path path = Paths.get(filePath);
        if (!Files.exists(path)) {
            log.warn("steps-extra.ndjson not found at {}, skipping enrichment", filePath);
            return Collections.emptyMap();
        }

        Map<String, StepExtra> result = new HashMap<>();

        try (BufferedReader reader = Files.newBufferedReader(path, StandardCharsets.UTF_8)) {
            String line;
            while ((line = reader.readLine()) != null) {
                line = line.trim();
                if (line.isEmpty()) continue;

                StepExtra extra = mapper.readValue(line, StepExtra.class);
                String key = key(extra.testCaseStartedId, extra.stepOrder);
                result.put(key, extra);
            }
        }

        log.info("Loaded {} step enrichment records from {}", result.size(), filePath);
        return result;
    }

    public static String key(String testCaseStartedId, int stepOrder) {
        return testCaseStartedId + ":" + stepOrder;
    }
}
